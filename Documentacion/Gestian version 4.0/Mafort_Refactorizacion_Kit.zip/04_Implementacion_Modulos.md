# Etapa 4
Implementar sin duplicar módulos, reutilizar formularios, crear Operaciones como dueño de OT.
