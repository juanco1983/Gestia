# Etapa 2
Diseñar arquitectura con SSOT. Clientes/Contratos=Comercial; OT=Operaciones; Informes=Técnicos; Facturación=Facturación.
