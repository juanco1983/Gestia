# Etapa 5
Validar navegación, roles, estados, compilación y pruebas funcionales.
