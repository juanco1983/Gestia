# Etapa 6
Backlog: PostgreSQL, GPS, Workflow, rutas, app móvil, notificaciones.
