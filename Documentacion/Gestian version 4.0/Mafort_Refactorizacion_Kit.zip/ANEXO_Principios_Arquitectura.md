# Principios
SSOT, SRP, RBAC y OT como entidad central.
