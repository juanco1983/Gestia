# LEEME
Ejecutar las etapas en orden y no avanzar sin aprobación.
