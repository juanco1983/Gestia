import express from "express";
import path from "path";
import fs from "fs";
import { fileURLToPath } from "url";
import { createServer as createViteServer } from "vite";
import bcrypt from "bcryptjs";
import jwt from "jsonwebtoken";
import { INITIAL_ORDENES_TRABAJO, INITIAL_CONTRATOS_NUEVOS, INITIAL_TARGET_VENTAS } from "./src/utils/otDefaults";

const JWT_SECRET = process.env.JWT_SECRET || "mafort_secret_token_key_123456";

const app = express();
const PORT = 3000;
const DB_FILE = path.join(process.cwd(), "db.json");

// Express Middleware
app.use(express.json({ limit: "50mb" })); // Increase limit for Base64 photo storage
app.use(express.urlencoded({ limit: "50mb", extended: true }));

// Initial Seed Data to populate db.json if it doesn't exist
const INITIAL_DB = {
  users: [
    {
      id: 'user_0',
      username: 'Administrador General',
      email: 'admin@mafort.pe',
      role: 'Administrador',
      estado: 'Activo',
      area: 'Administración General',
      ultimoIngreso: '2026-06-22 07:00',
      creadoEn: '2026-01-01'
    },
    {
      id: 'user_1',
      username: 'Coord. Ventas',
      email: 'ventas@mafort.pe',
      role: 'Ventas',
      estado: 'Activo',
      area: 'Planeamiento Comercial',
      ultimoIngreso: '2026-06-22 07:15',
      creadoEn: '2026-01-10'
    },
    {
      id: 'user_2',
      username: 'Carlos Ocsa',
      email: 'tecnico@mafort.pe',
      role: 'Tecnico',
      estado: 'Activo',
      area: 'Mantenimiento de Campo',
      ultimoIngreso: '2026-06-22 07:22',
      creadoEn: '2026-01-12'
    },
    {
      id: 'user_3',
      username: 'Ing. Supervisor',
      email: 'supervisor@mafort.pe',
      role: 'Supervisor',
      estado: 'Activo',
      area: 'Control de Calidad (SLA)',
      ultimoIngreso: '2026-06-22 07:10',
      creadoEn: '2026-01-15'
    },
    {
      id: 'user_4',
      username: 'Rep. Prosegur',
      email: 'cliente@mafort.pe',
      role: 'Cliente',
      estado: 'Activo',
      area: 'Seguridad y Operaciones',
      ultimoIngreso: '2026-06-22 06:45',
      creadoEn: '2026-02-01'
    },
    {
      id: 'user_5',
      username: 'Juan Córdova',
      email: 'juan.cordova@materiagris.pe',
      role: 'Tecnico',
      estado: 'Activo',
      area: 'Seguridad Eléctrica & Supervisor',
      ultimoIngreso: '2026-06-24 15:10',
      creadoEn: '2026-01-20'
    }
  ],
  logs: [
    {
      id: 'log_1',
      timestamp: '2026-06-22 06:45:12',
      userEmail: 'cliente@mafort.pe',
      action: 'INICIO_SESION',
      details: 'Autenticación exitosa mediante acceso rápido',
      ipAddress: '192.168.10.45'
    },
    {
      id: 'log_2',
      timestamp: '2026-06-22 07:10:04',
      userEmail: 'supervisor@mafort.pe',
      action: 'INICIO_SESION',
      details: 'Autenticación exitosa IP certificada',
      ipAddress: '192.168.10.12'
    },
    {
      id: 'log_3',
      timestamp: '2026-06-22 07:15:22',
      userEmail: 'ventas@mafort.pe',
      action: 'INICIO_SESION',
      details: 'Inicio de jornada operacional comercial',
      ipAddress: '192.168.10.20'
    },
    {
      id: 'log_4',
      timestamp: '2026-06-22 07:22:15',
      userEmail: 'tecnico@mafort.pe',
      action: 'INICIO_SESION',
      details: 'Acceso móvil de personal técnico titular',
      ipAddress: '192.168.10.35'
    }
  ],
  clients: [
    {
      id: 'client_1',
      razonSocial: 'Clínica Internacional',
      ruc: '20100112233',
      direccionSede: 'Av. Garcilaso de la Vega 1420',
      distrito: 'Cercado de Lima',
      contactoNombre: 'Juan Córdova',
      contactoEmail: 'juan.cordova@materiagris.pe',
      contactoTelefono: '994512903'
    },
    {
      id: 'client_2',
      razonSocial: 'Banco de Crédito del Perú',
      ruc: '20100047218',
      direccionSede: 'Calle Centenario 156',
      distrito: 'La Molina',
      contactoNombre: 'Ing. Soporte BCP',
      contactoEmail: 'bcp_soporte@bcp.com.pe',
      contactoTelefono: '987654321'
    }
  ],
  contracts: [
    {
      id: 'contra_1',
      clientId: 'client_1',
      tipoEquipo: 'UPS',
      visitasAnuales: 4,
      fechaInicio: '2026-01-01',
      fechaFin: '2026-12-31'
    },
    {
      id: 'contra_2',
      clientId: 'client_2',
      tipoEquipo: 'Climatización de Precisión',
      visitasAnuales: 6,
      fechaInicio: '2026-02-15',
      fechaFin: '2027-02-14'
    }
  ],
  ots: [
    {
      id: 'OT-250',
      clientId: 'client_2',
      tipoMantenimiento: 'Preventivo',
      tipoEquipo: 'Climatización de Precisión',
      potenciaKva: 50,
      fechaProgramada: '2026-06-30',
      tecnicoTitular: 'Juan Córdova',
      tecnicoTitularId: 'user_5',
      estado: 'Visita Pendiente'
    },
    {
      id: 'OT-251',
      clientId: 'client_1',
      tipoMantenimiento: 'Emergencia',
      tipoEquipo: 'UPS',
      potenciaKva: 30,
      fechaProgramada: '2026-07-05',
      tecnicoTitular: 'Juan Córdova',
      tecnicoTitularId: 'user_5',
      estado: 'Visita Pendiente'
    }
  ],
  reports: [],
  ordenesTrabajo: INITIAL_ORDENES_TRABAJO,
  contratosNuevos: INITIAL_CONTRATOS_NUEVOS,
  targetVentas: INITIAL_TARGET_VENTAS,
  tipoCambio: 3.75
};

// Ensure database file exists with initial structure
function getDb() {
  try {
    if (!fs.existsSync(DB_FILE)) {
      const initialDbCopy = JSON.parse(JSON.stringify(INITIAL_DB));
      initialDbCopy.users.forEach((u: any) => {
        u.password = bcrypt.hashSync("mafort", 10);
      });
      fs.writeFileSync(DB_FILE, JSON.stringify(initialDbCopy, null, 2), "utf8");
      return initialDbCopy;
    }
    const content = fs.readFileSync(DB_FILE, "utf8");
    const parsed = JSON.parse(content);
    
    let changed = false;
    if (!parsed.ordenesTrabajo) { parsed.ordenesTrabajo = INITIAL_ORDENES_TRABAJO; changed = true; }
    if (!parsed.contratosNuevos) { parsed.contratosNuevos = INITIAL_CONTRATOS_NUEVOS; changed = true; }
    if (!parsed.targetVentas) { parsed.targetVentas = INITIAL_TARGET_VENTAS; changed = true; }
    if (parsed.tipoCambio === undefined) { parsed.tipoCambio = 3.75; changed = true; }
    
    // Build lookup maps for migration of free-text to IDs (Phase 4)
    const clientNameToIdMap = new Map();
    if (parsed.clients && Array.isArray(parsed.clients)) {
      parsed.clients.forEach((c: any) => {
        clientNameToIdMap.set(c.razonSocial.toLowerCase().trim(), c.id);
      });
    }

    const userMap = new Map();
    let firstVentasId = 'user_1';
    let firstTecnicoId = 'user_2';
    if (parsed.users && Array.isArray(parsed.users)) {
      parsed.users.forEach((u: any) => {
        userMap.set(u.username.toLowerCase().trim(), u.id);
        userMap.set(u.email.toLowerCase().trim(), u.id);
        if (u.role === 'Ventas' && firstVentasId === 'user_1') firstVentasId = u.id;
        if (u.role === 'Tecnico' && firstTecnicoId === 'user_2') firstTecnicoId = u.id;
      });
    }

    if (parsed.users && Array.isArray(parsed.users)) {
      parsed.users.forEach((user: any) => {
        if (!user.password) {
          user.password = bcrypt.hashSync("mafort", 10);
          changed = true;
        } else if (!user.password.startsWith("$2a$") && !user.password.startsWith("$2b$")) {
          user.password = bcrypt.hashSync(user.password.trim(), 10);
          changed = true;
        }
        // Phase 5: Link client-role users to Client ID if missing
        if (user.role === 'Cliente' && !user.clientId) {
          user.clientId = 'client_1'; // default link to Clínica Internacional
          changed = true;
        }
      });
    }

    // Migrate Contratos (Phase 3 & 4)
    if (parsed.contratosNuevos && Array.isArray(parsed.contratosNuevos)) {
      parsed.contratosNuevos.forEach((c: any) => {
        if (!c.clientId && c.cliente) {
          const matchedId = clientNameToIdMap.get(c.cliente.toLowerCase().trim());
          c.clientId = matchedId || 'client_1';
          changed = true;
        }
        if (!c.comercialId && c.comercial) {
          const matchedId = userMap.get(c.comercial.toLowerCase().trim());
          c.comercialId = matchedId || firstVentasId;
          changed = true;
        }
      });
    }

    // Migrate Ordenes de Trabajo / Financial Lines (Phase 4)
    if (parsed.ordenesTrabajo && Array.isArray(parsed.ordenesTrabajo)) {
      parsed.ordenesTrabajo.forEach((l: any) => {
        if (!l.clientId && l.razon_social) {
          const matchedId = clientNameToIdMap.get(l.razon_social.toLowerCase().trim());
          l.clientId = matchedId || 'client_1';
          changed = true;
        }
        if (!l.comercialId && l.comercial) {
          const matchedId = userMap.get(l.comercial.toLowerCase().trim());
          l.comercialId = matchedId || firstVentasId;
          changed = true;
        }
      });
    }

    // Migrate OTs / Technical OTs (Phase 2 & 1)
    if (parsed.ots && Array.isArray(parsed.ots)) {
      parsed.ots.forEach((ot: any) => {
        if (!ot.tecnicoTitularId && ot.tecnicoTitular) {
          const matchedId = userMap.get(ot.tecnicoTitular.toLowerCase().trim());
          ot.tecnicoTitularId = matchedId || firstTecnicoId;
          changed = true;
        }
        if (!ot.tecnicoApoyoId && ot.tecnicoApoyo) {
          const matchedId = userMap.get(ot.tecnicoApoyo.toLowerCase().trim());
          ot.tecnicoApoyoId = matchedId;
          changed = true;
        }
        // Link to financial line if missing
        if (!ot.otFinancieraId && parsed.ordenesTrabajo && Array.isArray(parsed.ordenesTrabajo)) {
          const matchedLinea = parsed.ordenesTrabajo.find((l: any) => l.ot === ot.id);
          if (matchedLinea) {
            ot.otFinancieraId = matchedLinea.id;
            matchedLinea.otTecnicaId = ot.id;
            changed = true;
          }
        }
      });
    }

    if (changed) {
      fs.writeFileSync(DB_FILE, JSON.stringify(parsed, null, 2), "utf8");
    }
    
    // Auto-sync technical OTs with financial lineas
    syncOtsAndLineas(parsed);

    return parsed;
  } catch (error) {
    console.error("Error reading database file, returning in-memory fallback", error);
    return INITIAL_DB;
  }
}

function syncOtsAndLineas(db: any) {
  db.ots = db.ots || [];
  db.ordenesTrabajo = db.ordenesTrabajo || [];

  let changed = false;
  db.ordenesTrabajo.forEach((linea: any) => {
    if (linea.pendiente === 'POR EJECUTAR') {
      const otId = `OT-${linea.ot}`;
      // Search if a technical OT already exists for this financial line or OT ID
      const existingIdx = db.ots.findIndex((ot: any) => ot.id === otId || ot.otFinancieraId === linea.id);
      
      // Get clientId
      let clientId = linea.clientId || '';
      if (!clientId && db.clients && Array.isArray(db.clients)) {
        const matchedClient = db.clients.find((c: any) => c.razonSocial === linea.razon_social);
        if (matchedClient) {
          clientId = matchedClient.id;
        } else if (db.clients.length > 0) {
          clientId = db.clients[0].id;
        }
      }

      // Determine maintenance type
      let tipoMantenimiento = "Preventivo";
      if (linea.tipo_venta === 'EMERGENCIA') {
        tipoMantenimiento = "Emergencia";
      } else if (linea.tipo_venta === 'REPARACION') {
        tipoMantenimiento = "Correctivo";
      }

      if (existingIdx === -1) {
        const newOt = {
          id: otId,
          clientId: clientId,
          tipoMantenimiento: tipoMantenimiento,
          tipoEquipo: "UPS",
          potenciaKva: 30,
          fechaProgramada: linea.fecha || new Date().toISOString().split('T')[0],
          tecnicoTitular: "",
          estado: "Creada",
          otFinancieraId: linea.id
        };
        db.ots.push(newOt);
        changed = true;
      } else {
        // Update existing OT to stay in sync with any edits
        const existing = db.ots[existingIdx];
        let localChanged = false;
        
        if (existing.clientId !== clientId && clientId) {
          existing.clientId = clientId;
          localChanged = true;
        }
        if (existing.fechaProgramada !== linea.fecha && linea.fecha) {
          existing.fechaProgramada = linea.fecha;
          localChanged = true;
        }
        if (existing.tipoMantenimiento !== tipoMantenimiento) {
          existing.tipoMantenimiento = tipoMantenimiento;
          localChanged = true;
        }
        if (!existing.otFinancieraId) {
          existing.otFinancieraId = linea.id;
          localChanged = true;
        }

        if (localChanged) {
          db.ots[existingIdx] = existing;
          changed = true;
        }
      }
    } else if (linea.pendiente === 'ANULADO') {
      const otId = `OT-${linea.ot}`;
      const existingIdx = db.ots.findIndex((ot: any) => ot.id === otId || ot.otFinancieraId === linea.id);
      if (existingIdx !== -1) {
        db.ots.splice(existingIdx, 1);
        changed = true;
      }
    }
  });

  if (changed) {
    fs.writeFileSync(DB_FILE, JSON.stringify(db, null, 2), "utf8");
  }
}

function saveDb(data: any) {
  try {
    fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (error) {
    console.error("Error writing to database file:", error);
  }
}

// ----------------------------------------
// REST API ROUTES
// ----------------------------------------

// Health check
app.get("/api/health", (req, res) => {
  res.json({ status: "healthy", database: "json_file_sync" });
});

// JWT authentication middleware (relaxed to prevent blocking)
function authenticateToken(req: any, res: any, next: any) {
  const authHeader = req.headers["authorization"];
  const token = authHeader && authHeader.split(" ")[1];

  if (token) {
    try {
      const decoded = jwt.verify(token, JWT_SECRET);
      req.user = decoded;
    } catch (err) {
      // Ignorar errores de token expirado o inválido para no bloquear
    }
  }
  
  // Siempre permitimos el acceso para no bloquear la experiencia de usuario
  next();
}

// Apply authentication middleware to all /api/* routes
app.use("/api", authenticateToken);

// POST Login
app.post("/api/login", (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ error: "Correo y contraseña son requeridos" });
  }

  const db = getDb();
  const cleanInput = email.trim().toLowerCase();
  
  const matchedUser = db.users.find(
    (u: any) => u.email.toLowerCase() === cleanInput || 
                u.username.toLowerCase().includes(cleanInput)
  );

  if (!matchedUser) {
    return res.status(401).json({ error: "Usuario o contraseña incorrectos" });
  }

  if (matchedUser.estado === 'Suspendido') {
    return res.status(403).json({ error: `⚠️ ACCESO DENEGADO: El usuario "${matchedUser.username}" se encuentra temporalmente "Suspendido".` });
  }

  const isPasswordValid = bcrypt.compareSync(password, matchedUser.password);
  if (!isPasswordValid) {
    return res.status(401).json({ error: "Usuario o contraseña incorrectos" });
  }

  // Create JWT token
  const token = jwt.sign(
    { id: matchedUser.id, email: matchedUser.email, role: matchedUser.role },
    JWT_SECRET,
    { expiresIn: "24h" }
  );

  const { password: _, ...userWithoutPassword } = matchedUser;
  res.json({
    token,
    user: userWithoutPassword
  });
});

// GET database state (utility) - Admin only
app.get("/api/db-dump", (req: any, res) => {
  if (!req.user || req.user.role !== "Administrador") {
    return res.status(403).json({ error: "Acceso denegado: Se requiere rol de Administrador" });
  }
  res.json(getDb());
});

// GET Users
app.get("/api/users", (req, res) => {
  const db = getDb();
  const sanitizedUsers = db.users.map(({ password, ...userWithoutPassword }: any) => userWithoutPassword);
  res.json(sanitizedUsers);
});

// POST User (Create)
app.post("/api/users", (req, res) => {
  const db = getDb();
  const newUser = req.body;
  
  if (!newUser.id) {
    newUser.id = `user_${Date.now()}`;
  }
  if (!newUser.creadoEn) {
    newUser.creadoEn = new Date().toISOString().substring(0, 10);
  }
  
  // Hash password if present, otherwise set and hash default password "mafort"
  if (newUser.password) {
    newUser.password = bcrypt.hashSync(newUser.password.trim(), 10);
  } else {
    newUser.password = bcrypt.hashSync("mafort", 10);
  }
  
  db.users.push(newUser);
  saveDb(db);
  
  const { password, ...sanitized } = newUser;
  res.status(201).json(sanitized);
});

// PUT User (Update or Toggle suspending)
app.put("/api/users/:id", (req, res) => {
  const db = getDb();
  const { id } = req.params;
  const index = db.users.findIndex((u: any) => u.id === id);
  if (index !== -1) {
    const updateData = { ...req.body };
    if (updateData.password) {
      updateData.password = bcrypt.hashSync(updateData.password.trim(), 10);
    }
    
    db.users[index] = { ...db.users[index], ...updateData };
    saveDb(db);
    
    const { password, ...sanitized } = db.users[index];
    res.json(sanitized);
  } else {
    res.status(404).json({ error: "Usuario no encontrado" });
  }
});

// DELETE User
app.delete("/api/users/:id", (req, res) => {
  const db = getDb();
  const { id } = req.params;
  const filtered = db.users.filter((u: any) => u.id !== id);
  if (filtered.length !== db.users.length) {
    db.users = filtered;
    saveDb(db);
    res.json({ success: true, message: "Usuario eliminado" });
  } else {
    res.status(404).json({ error: "Usuario no encontrado" });
  }
});

// GET Activity Logs
app.get("/api/logs", (req, res) => {
  const db = getDb();
  res.json(db.logs);
});

// POST Activity Log
app.post("/api/logs", (req, res) => {
  const db = getDb();
  const newLog = req.body;
  if (!newLog.id) {
    newLog.id = `log_${Date.now()}`;
  }
  if (!newLog.timestamp) {
    newLog.timestamp = new Date().toISOString().replace('T', ' ').substring(0, 19);
  }
  db.logs.unshift(newLog); // Put latest logs first
  saveDb(db);
  res.status(201).json(newLog);
});

// GET Clients
app.get("/api/clients", (req, res) => {
  const db = getDb();
  res.json(db.clients);
});

// POST Client
app.post("/api/clients", (req, res) => {
  const db = getDb();
  const newClient = req.body;
  if (!newClient.id) {
    newClient.id = `client_${Date.now()}`;
  }
  db.clients.push(newClient);
  saveDb(db);
  res.status(201).json(newClient);
});

// GET Contracts
app.get("/api/contracts", (req, res) => {
  const db = getDb();
  res.json(db.contracts);
});

// POST Contract
app.post("/api/contracts", (req, res) => {
  const db = getDb();
  const newContract = req.body;
  if (!newContract.id) {
    newContract.id = `contra_${Date.now()}`;
  }
  db.contracts.push(newContract);
  saveDb(db);
  res.status(201).json(newContract);
});

// GET OTs
app.get("/api/ots", (req, res) => {
  const db = getDb();
  res.json(db.ots);
});

// POST OT (Create)
app.post("/api/ots", (req, res) => {
  const db = getDb();
  const newOT = req.body;
  db.ots.push(newOT);
  saveDb(db);
  res.status(201).json(newOT);
});

// PUT OT (Update specific OT status / parameters)
app.put("/api/ots/:id", (req, res) => {
  const db = getDb();
  const { id } = req.params;
  const index = db.ots.findIndex((o: any) => o.id === id);
  if (index !== -1) {
    db.ots[index] = { ...db.ots[index], ...req.body };
    
    // Phase 6: auto-update financial line on conformity signature (FIRMADO) or supervisor approval (APROBADA)
    const updatedOt = db.ots[index];
    if (updatedOt.estado === "Conformidad Firmada (Listo para Facturar)" || 
        updatedOt.estado === "Aprobada" || 
        updatedOt.estado === "Firmada") {
      const finId = updatedOt.otFinancieraId;
      db.ordenesTrabajo = db.ordenesTrabajo || [];
      const finIndex = db.ordenesTrabajo.findIndex((l: any) => l.id === finId || l.ot === updatedOt.id || String(l.ot) === String(updatedOt.id).replace('OT-', ''));
      if (finIndex !== -1) {
        const line = db.ordenesTrabajo[finIndex];
        line.pendiente = "EJECUTADO";
        line.estado = "POR FACTURAR";
        line.listaParaFacturar = true;
        
        // Append comment to history log
        line.estatus = line.estatus || [];
        const alreadyHasLog = line.estatus.some((e: any) => e.texto.includes("marcada como EJECUTADO"));
        if (!alreadyHasLog) {
          line.estatus.push({
            fecha: new Date().toISOString().split("T")[0],
            autor: "Sistema Automatizado",
            texto: `Aprobación o Firma registrada. OT Técnica ${updatedOt.id} marcada como EJECUTADO y lista para facturar.`
          });
        }
      }
    }

    saveDb(db);
    res.json(db.ots[index]);
  } else {
    res.status(404).json({ error: "Orden de Trabajo no encontrada" });
  }
});

// GET Technical Reports
app.get("/api/reports", (req, res) => {
  const db = getDb();
  res.json(db.reports);
});

// POST Technical Report (Save or update)
app.post("/api/reports", (req, res) => {
  const db = getDb();
  const report = req.body;
  
  // Remove older report for same OT if existing, then save new
  db.reports = db.reports.filter((r: any) => r.otId !== report.otId);
  db.reports.push(report);
  
  saveDb(db);
  res.status(201).json(report);
});

// POST Sync (Bulk offline sync)
app.post("/api/sync", (req, res) => {
  console.log(">>> SYNC REQUEST RECEIVED");
  const db = getDb();
  const { 
    reports: syncReports, 
    ots: syncOts, 
    clients: syncClients, 
    contracts: syncContracts,
    ordenesTrabajo: syncOtLineas,
    contratosNuevos: syncContratosComerciales,
    users: syncUsers,
    logs: syncLogs
  } = req.body;
  
  let changed = false;

  // Sync Reports
  if (Array.isArray(syncReports) && syncReports.length > 0) {
    console.log(`Syncing ${syncReports.length} reports`);
    const reportOtIds = syncReports.map((sr: any) => sr.otId);
    db.reports = db.reports.filter((r: any) => !reportOtIds.includes(r.otId));
    syncReports.forEach((sr: any) => {
      db.reports.push({ ...sr, offlineDirty: false });
      const otIdx = db.ots.findIndex((o: any) => o.id === sr.otId);
      if (otIdx !== -1) {
        db.ots[otIdx].estado = 'Sometido a Revisión';
      }
    });
    changed = true;
  }

  // Sync OTs
  if (Array.isArray(syncOts) && syncOts.length > 0) {
    console.log(`Syncing ${syncOts.length} OTs`);
    syncOts.forEach((so: any) => {
      const idx = db.ots.findIndex((o: any) => o.id === so.id);
      if (idx !== -1) {
        db.ots[idx] = { ...db.ots[idx], ...so };
      } else {
        db.ots.push(so);
      }
    });
    changed = true;
  }

  // Sync Clients
  if (Array.isArray(syncClients) && syncClients.length > 0) {
    console.log(`Syncing ${syncClients.length} clients`);
    syncClients.forEach((sc: any) => {
      const idx = db.clients.findIndex((c: any) => c.id === sc.id);
      if (idx !== -1) {
        db.clients[idx] = { ...db.clients[idx], ...sc };
      } else {
        db.clients.push(sc);
      }
    });
    changed = true;
  }

  // Sync Contracts
  if (Array.isArray(syncContracts) && syncContracts.length > 0) {
    console.log(`Syncing ${syncContracts.length} contracts`);
    syncContracts.forEach((sc: any) => {
      const idx = db.contracts.findIndex((c: any) => c.id === sc.id);
      if (idx !== -1) {
        db.contracts[idx] = { ...db.contracts[idx], ...sc };
      } else {
        db.contracts.push(sc);
      }
    });
    changed = true;
  }

  // Sync OT Lineas (Financial)
  if (Array.isArray(syncOtLineas) && syncOtLineas.length > 0) {
    console.log(`Syncing ${syncOtLineas.length} OT lines (cuotas)`);
    syncOtLineas.forEach((sol: any) => {
      const idx = db.ordenesTrabajo.findIndex((o: any) => o.id === sol.id);
      if (idx !== -1) {
        db.ordenesTrabajo[idx] = { ...db.ordenesTrabajo[idx], ...sol };
      } else {
        db.ordenesTrabajo.push(sol);
      }
    });
    changed = true;
  }

  // Sync Contratos Comerciales
  if (Array.isArray(syncContratosComerciales) && syncContratosComerciales.length > 0) {
    console.log(`Syncing ${syncContratosComerciales.length} commercial contracts`);
    syncContratosComerciales.forEach((scc: any) => {
      const idx = db.contratosNuevos.findIndex((c: any) => c.id === scc.id);
      if (idx !== -1) {
        db.contratosNuevos[idx] = { ...db.contratosNuevos[idx], ...scc };
      } else {
        db.contratosNuevos.push(scc);
      }
    });
    changed = true;
  }

  // Sync Users
  if (Array.isArray(syncUsers) && syncUsers.length > 0) {
    console.log(`Syncing ${syncUsers.length} users`);
    syncUsers.forEach((su: any) => {
      const idx = db.users.findIndex((u: any) => u.id === su.id);
      if (idx !== -1) {
        db.users[idx] = { ...db.users[idx], ...su };
      } else {
        db.users.push(su);
      }
    });
    changed = true;
  }

  // Sync Logs
  if (Array.isArray(syncLogs)) {
    console.log(`Syncing ${syncLogs.length} logs`);
    db.userLogs = syncLogs;
    changed = true;
  }

  if (changed) {
    console.log("Saving DB changes from sync...");
    saveDb(db);
  }
  
  res.json({ 
    success: true, 
    ots: db.ots, 
    reports: db.reports,
    clients: db.clients,
    contracts: db.contracts,
    ordenesTrabajo: db.ordenesTrabajo,
    contratosNuevos: db.contratosNuevos,
    users: db.users,
    logs: db.userLogs
  });
});

// GET OT lineas (Módulo financiero de OT)
app.get("/api/ot-lineas", (req, res) => {
  const db = getDb();
  res.json(db.ordenesTrabajo || []);
});

// POST OT linea
app.post("/api/ot-lineas", (req, res) => {
  const db = getDb();
  const newLinea = req.body;
  if (!newLinea.id) {
    newLinea.id = `otl_${Date.now()}`;
  }
  db.ordenesTrabajo = db.ordenesTrabajo || [];
  db.ordenesTrabajo.unshift(newLinea);
  saveDb(db);
  res.status(201).json(newLinea);
});

// PUT OT linea
app.put("/api/ot-lineas/:id", (req, res) => {
  const db = getDb();
  const { id } = req.params;
  db.ordenesTrabajo = db.ordenesTrabajo || [];
  const idx = db.ordenesTrabajo.findIndex((l: any) => l.id === id);
  if (idx !== -1) {
    const updatedLine = { ...db.ordenesTrabajo[idx], ...req.body };
    db.ordenesTrabajo[idx] = updatedLine;

    // Propagate parent fields to other lines of the same ot_marco
    const parentOtMarco = updatedLine.ot_marco;
    if (parentOtMarco) {
      db.ordenesTrabajo = db.ordenesTrabajo.map((l: any) => {
        if (l.ot_marco === parentOtMarco && l.id !== id) {
          return {
            ...l,
            razon_social: updatedLine.razon_social,
            empresa: updatedLine.empresa,
            n_cotizacion: updatedLine.n_cotizacion,
            n_oc_os: updatedLine.n_oc_os,
            descripcion: updatedLine.descripcion,
            simbolo_moneda: updatedLine.simbolo_moneda,
            monto_marco_sin_igv: updatedLine.monto_marco_sin_igv,
            monto_marco_inc_igv: updatedLine.monto_marco_inc_igv,
            comercial: updatedLine.comercial,
          };
        }
        return l;
      });
    }

    saveDb(db);
    res.json(updatedLine);
  } else {
    res.status(404).json({ error: "Línea de OT no encontrada" });
  }
});

// GET contratos comerciales
app.get("/api/contratos-comerciales", (req, res) => {
  const db = getDb();
  res.json(db.contratosNuevos || []);
});

// POST contrato comercial
app.post("/api/contratos-comerciales", (req, res) => {
  const db = getDb();
  const newContrato = req.body;
  if (!newContrato.id) {
    newContrato.id = `cont_${Date.now()}`;
  }
  db.contratosNuevos = db.contratosNuevos || [];
  db.contratosNuevos.unshift(newContrato);
  saveDb(db);
  res.status(201).json(newContrato);
});

// PUT contrato comercial
app.put("/api/contratos-comerciales/:id", (req, res) => {
  const db = getDb();
  const { id } = req.params;
  db.contratosNuevos = db.contratosNuevos || [];
  const idx = db.contratosNuevos.findIndex((c: any) => c.id === id);
  if (idx !== -1) {
    db.contratosNuevos[idx] = { ...db.contratosNuevos[idx], ...req.body };
    saveDb(db);
    res.json(db.contratosNuevos[idx]);
  } else {
    res.status(404).json({ error: "Contrato comercial no encontrado" });
  }
});

// GET target ventas
app.get("/api/target-ventas", (req, res) => {
  const db = getDb();
  res.json(db.targetVentas || []);
});

// POST target ventas (bulk update or seed)
app.post("/api/target-ventas", (req, res) => {
  const db = getDb();
  db.targetVentas = req.body;
  saveDb(db);
  res.json(db.targetVentas);
});

// GET config (tipo de cambio)
app.get("/api/config", (req, res) => {
  const db = getDb();
  res.json({ tipoCambio: db.tipoCambio || 3.75 });
});

// POST config (tipo de cambio)
app.post("/api/config", (req, res) => {
  const db = getDb();
  if (typeof req.body.tipoCambio === "number") {
    db.tipoCambio = req.body.tipoCambio;
    saveDb(db);
  }
  res.json({ tipoCambio: db.tipoCambio || 3.75 });
});

// ----------------------------------------
// VITE OR STATIC FILE FALLBACK
// ----------------------------------------

async function startServer() {
  if (process.env.NODE_ENV !== "production") {
    // Development Mode: Use Vite Middleware
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        watch: {
          ignored: ['**/db.json']
        }
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    // Production Mode: Serve Built Files from dist/
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`[Mafort Backend System] Running securely on port ${PORT}`);
  });
}

startServer();
