import React, { useState, useEffect } from 'react';
import { INITIAL_CLIENTS, INITIAL_CONTRACTS, INITIAL_OTS, INITIAL_USERS, INITIAL_LOGS } from './mockData';
import { Client, Contract, OT, OTStatus, TechnicalReport, User, UserActivityLog, OrdenTrabajoLinea, Contrato, TargetVentas, ServiceType, EquipmentType } from './types';
import { INITIAL_ORDENES_TRABAJO, INITIAL_CONTRATOS_NUEVOS, INITIAL_TARGET_VENTAS } from './utils/otDefaults';
import OrdenesTrabajoView from './components/OrdenesTrabajoView';
import ClientesContratosView from './components/ClientesContratosView';
import VentasView from './components/VentasView';
import TecnicoView from './components/TecnicoView';
import SupervisorView from './components/SupervisorView';
import ClienteView from './components/ClienteView';
import LoginView from './components/LoginView';
import UserManagementView from './components/UserManagementView';
import TechMonitoringDashboard from './components/TechMonitoringDashboard';
import { APP_MODULES } from './modulesConfig';
import { 
  AlertCircle, 
  Terminal, 
  LayoutDashboard, 
  PhoneCall, 
  Wrench, 
  ShieldCheck, 
  Briefcase, 
  Users, 
  LogOut, 
  Search, 
  Wifi, 
  WifiOff, 
  RefreshCw, 
  FileText, 
  Activity, 
  ArrowUpRight,
  Menu,
  Bell,
  Play,
  Calendar,
  Building2
} from 'lucide-react';

// Helper components for the main dashboard mockup look
interface CircularProgressProps {
  value: number;
  total: number;
  label?: string;
  color?: string;
  size?: number;
}

function CircularProgress({ value, total, label, color = '#00B594', size = 42 }: CircularProgressProps) {
  const percentage = total > 0 ? (value / total) * 100 : 0;
  const radius = 13.5;
  const circumference = 2 * Math.PI * radius; // approx 84.82
  const strokeDashoffset = circumference - (circumference * percentage) / 100;

  return (
    <div className="relative flex items-center justify-center shrink-0 animate-fade-in" style={{ width: size, height: size }}>
      <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
        <circle
          cx="18"
          cy="18"
          r={radius}
          className="text-slate-150"
          strokeWidth="3.2"
          stroke="currentColor"
          fill="none"
        />
        <circle
          cx="18"
          cy="18"
          r={radius}
          strokeWidth="3.2"
          strokeDasharray={circumference}
          strokeDashoffset={strokeDashoffset}
          strokeLinecap="round"
          stroke={color}
          fill="none"
          className="transition-all duration-500"
        />
      </svg>
      <div className="absolute font-sans text-[8.5px] font-black text-slate-700 leading-none">
        {label || `${value}/${total}`}
      </div>
    </div>
  );
}

function OperationalPerformanceChart() {
  return (
    <div className="w-full bg-white border border-slate-100/80 rounded-[24px] p-6 flex flex-col justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)]" id="perf-chart-box">
      
      <div className="flex items-center justify-between mb-4">
        <div>
          <h4 className="text-sm font-extrabold text-slate-900 tracking-tight">Rendimiento Operativo Clave</h4>
          <p className="text-xs text-slate-400 font-medium mt-0.5">Voltajes de salida promedios frente a perturbaciones de carga</p>
        </div>
        <span className="bg-[#E6F7F4] text-[#00B594] px-2.5 py-1 rounded-full text-[10px] font-bold">
          +2.05% Incremental SLA
        </span>
      </div>

      {/* Simulated interactive Area Chart using standard SVG for flawless layout */}
      <div className="relative h-[220px] w-full border border-slate-100 rounded-2xl overflow-hidden bg-white">
        
        {/* Horizontal grid lines */}
        <div className="absolute inset-0 flex flex-col justify-between py-6 pointer-events-none opacity-40">
          <div className="border-b border-dashed border-slate-100 w-full"></div>
          <div className="border-b border-dashed border-slate-100 w-full"></div>
          <div className="border-b border-dashed border-slate-100 w-full"></div>
          <div className="border-b border-dashed border-slate-100 w-full"></div>
        </div>

        {/* SVG Area & Line */}
        <svg className="w-full h-full" viewBox="0 0 600 180" preserveAspectRatio="none">
          <defs>
            <linearGradient id="chartGrad" x1="0" y1="0" x2="0" y2="1">
              <stop offset="0%" stopColor="#00B594" stopOpacity="0.18" />
              <stop offset="100%" stopColor="#00B594" stopOpacity="0.0" />
            </linearGradient>
          </defs>

          {/* Grid vertical markings */}
          <line x1="50" y1="0" x2="50" y2="150" stroke="#f8fafc" strokeWidth="1" />
          <line x1="150" y1="0" x2="150" y2="150" stroke="#f8fafc" strokeWidth="1" />
          <line x1="250" y1="0" x2="250" y2="150" stroke="#f8fafc" strokeWidth="1" />
          <line x1="350" y1="0" x2="350" y2="150" stroke="#f8fafc" strokeWidth="1" />
          <line x1="450" y1="0" x2="450" y2="150" stroke="#f8fafc" strokeWidth="1" />
          <line x1="550" y1="0" x2="550" y2="150" stroke="#f8fafc" strokeWidth="1" />

          {/* Closed Area under the curve */}
          <path
            d="M 20,130 
               C 60,110  100,105 140,115
               C 180,125 220,95  260,75
               C 300,55  340,55  380,100
               C 400,120 420,150 450,150
               L 450,180 L 20,180 Z"
            fill="url(#chartGrad)"
          />

          {/* Main Curved Line - Segment 1 */}
          <path
            d="M 20,130 
               C 60,110  100,105 140,115
               C 180,125 220,95  260,75
               C 300,55  340,55  380,100
               C 400,120 420,150 450,150"
            fill="none"
            stroke="#00B594"
            strokeWidth="3.2"
            strokeLinecap="round"
          />

          {/* Second Line Segment (after gap or drop) */}
          <path
            d="M 480,140 
               C 500,110 520,70  550,85
               C 570,95  590,100 600,105"
            fill="none"
            stroke="#00B594"
            strokeWidth="3.2"
            strokeLinecap="round"
          />
          
          {/* Dots at key coordinates */}
          {/* Dot 1 */}
          <circle cx="140" cy="115" r="4.5" fill="#00B594" stroke="white" strokeWidth="2.2" />
          {/* Dot 2 */}
          <circle cx="260" cy="75" r="4.5" fill="#00B594" stroke="white" strokeWidth="2.2" />
          {/* Dot 3 */}
          <circle cx="340" cy="55" r="4.5" fill="#00B594" stroke="white" strokeWidth="2.2" />
          {/* Dot 4 */}
          <circle cx="550" cy="85" r="4.5" fill="#00B594" stroke="white" strokeWidth="2.2" />

        </svg>

        {/* Floating axis month labels */}
        <div className="absolute bottom-1.5 left-0 right-0 flex justify-between px-6 text-[9px] font-bold text-slate-400 font-mono">
          <span>Ene</span>
          <span>Feb</span>
          <span>Mar</span>
          <span>Abr</span>
          <span>May</span>
          <span>Jun (Actual)</span>
        </div>
      </div>

      {/* Bottom 3 statistics tiles */}
      <div className="grid grid-cols-3 gap-3 mt-4 text-center">
        <div className="bg-slate-50 border border-slate-100 rounded-xl py-2.5">
          <span className="text-[9px] font-extrabold uppercase tracking-wider text-slate-450 block font-mono">Carga UPS Promedio:</span>
          <span className="text-xs font-black text-slate-800 block mt-0.5">86.75% KVA</span>
        </div>
        <div className="bg-slate-50 border border-slate-100 rounded-xl py-2.5">
          <span className="text-[9px] font-extrabold uppercase tracking-wider text-slate-450 block font-mono">Estabilidad Térmica:</span>
          <span className="text-xs font-black text-slate-800 block mt-0.5"><span className="text-[#00B594]">22.4 °C Opt</span></span>
        </div>
        <div className="bg-slate-50 border border-slate-100 rounded-xl py-2.5">
          <span className="text-[9px] font-extrabold uppercase tracking-wider text-slate-450 block font-mono">Acumuladores:</span>
          <span className="text-xs font-black text-slate-800 block mt-0.5"><span className="text-[#F59E0B]">2/14 Bypass</span></span>
        </div>
      </div>

    </div>
  );
}

function TechHoursChart() {
  const barData = [
    { day: 'Lun', hours: '8h', height: '80%' },
    { day: 'Mar', hours: '7h', height: '70%' },
    { day: 'Mié', hours: '9h', height: '90%' },
    { day: 'Jue', hours: '5h', height: '50%' },
    { day: 'Vie', hours: '8.5h', height: '85%' },
    { day: 'Sáb', hours: '4h', height: '40%' },
    { day: 'Dos', hours: '0h', height: '6%' } // Represented as Dom/Dos in mockup
  ];
  return (
    <div className="w-full bg-white border border-slate-100/80 rounded-[24px] p-6 flex flex-col justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)]" id="hours-chart-box">
      <div>
        <h4 className="text-sm font-extrabold text-slate-900 tracking-tight">Horas Técnicas Registradas</h4>
        <p className="text-xs text-slate-400 font-medium mt-0.5">Mantenimiento de UPS en la presente semana</p>
      </div>

      {/* Bar container */}
      <div className="h-[220px] border border-slate-100 rounded-2xl bg-white flex items-end justify-between px-5 py-4 relative mt-4">
        {barData.map((b, idx) => (
          <div key={idx} className="flex flex-col items-center justify-end h-full w-[10%]">
            <span className="text-[9px] font-bold text-slate-450 font-mono mb-1">{b.hours}</span>
            <div className="w-full bg-slate-100 h-[110px] rounded-full overflow-hidden flex flex-col justify-end">
              <div 
                className="bg-[#00B594] rounded-full transition-all duration-500" 
                style={{ height: b.height }}
              ></div>
            </div>
            <span className="text-[9px] font-extrabold text-slate-400 font-sans mt-2">{b.day}</span>
          </div>
        ))}
      </div>

      <div className="mt-4 text-center py-2.5 bg-slate-50 border border-slate-100 rounded-xl">
        <p className="text-[10px] font-bold text-slate-500 font-mono">
          Total de Horas registradas: <strong className="text-slate-700 font-black">41.5 Hrs</strong> (SLA Cubierto)
        </p>
      </div>
    </div>
  );
}

const getAppDefaultModulesForRole = (role: string): string[] => {
  if (role === 'Administrador') {
    return ['Dashboard', 'Monitoreo', 'GestionOTs', 'ClientesContratos', 'Ventas', 'Tecnico', 'Supervisor', 'Cliente', 'Usuarios'];
  } else if (role === 'Ventas') {
    return ['Dashboard', 'Monitoreo', 'GestionOTs', 'ClientesContratos', 'Ventas'];
  } else if (role === 'Tecnico') {
    return ['Dashboard', 'Monitoreo', 'Tecnico'];
  } else if (role === 'Supervisor') {
    return ['Dashboard', 'Monitoreo', 'Supervisor'];
  } else if (role === 'Cliente') {
    return ['Dashboard', 'Monitoreo', 'Cliente'];
  }
  return ['Dashboard', 'Monitoreo'];
};

export default function App() {
  // Live dynamic list of users
  const [users, setUsers] = useState<User[]>(() => {
    const local = localStorage.getItem('mafort_users');
    const parsed = local ? JSON.parse(local) : INITIAL_USERS;
    if (Array.isArray(parsed)) {
      let changed = false;
      const updated = parsed.map((u: any) => {
        if (!u.allowedModules || u.allowedModules.length === 0) {
          u.allowedModules = getAppDefaultModulesForRole(u.role);
          changed = true;
        }
        return u;
      });
      if (changed) {
        localStorage.setItem('mafort_users', JSON.stringify(updated));
      }
      return updated;
    }
    return INITIAL_USERS;
  });

  // Dynamic security activity logs
  const [userLogs, setUserLogs] = useState<UserActivityLog[]>(() => {
    const local = localStorage.getItem('mafort_user_logs');
    return local ? JSON.parse(local) : INITIAL_LOGS;
  });

  const [currentUser, setCurrentUser] = useState<User | null>(() => {
    const local = localStorage.getItem('mafort_current_user');
    if (local) {
      try {
        const u = JSON.parse(local) as User;
        if (u && (!u.allowedModules || u.allowedModules.length === 0)) {
          u.allowedModules = getAppDefaultModulesForRole(u.role);
          localStorage.setItem('mafort_current_user', JSON.stringify(u));
        }
        return u;
      } catch (e) {
        return null;
      }
    }
    return null;
  });

  // Active view tab switcher
  const [currentRole, setCurrentRole] = useState<'Dashboard' | 'Ventas' | 'Tecnico' | 'Supervisor' | 'Cliente' | 'Usuarios' | 'GestionOTs' | 'ClientesContratos'>(() => {
    const local = localStorage.getItem('mafort_current_user');
    if (local) {
      try {
        const u = JSON.parse(local) as User;
        if (u && u.role) return u.role;
      } catch (e) {
        // Fallback
      }
    }
    return 'Dashboard';
  });
  
  // Search query
  const [searchQuery, setSearchQuery] = useState('');

  // Dashboard sub-tab switcher
  const [dashboardSubTab, setDashboardSubTab] = useState<'analytics' | 'monitoring'>('analytics');

  // Real-time online state
  const [isOnline, setIsOnline] = useState<boolean>(true);

  // Sidebar visibility state
  const [isSidebarOpen, setIsSidebarOpen] = useState<boolean>(true);

  // Logout confirmation state
  const [showLogoutConfirm, setShowLogoutConfirm] = useState(false);

  // Persistent States loaded from localStorage
  const [clients, setClients] = useState<Client[]>(() => {
    const local = localStorage.getItem('mafort_clients');
    if (local) {
      const parsed = JSON.parse(local);
      const containsOldData = parsed.some((c: any) => 
        c.razonSocial?.includes('Repsol') || 
        c.razonSocial?.includes('San Pablo') || 
        c.razonSocial?.includes('Prosegur')
      );
      if (!containsOldData && parsed.length > 0) return parsed;
    }
    return INITIAL_CLIENTS;
  });

  const [contracts, setContracts] = useState<Contract[]>(() => {
    const local = localStorage.getItem('mafort_contracts');
    if (local) {
      const parsed = JSON.parse(local);
      if (parsed.length <= 2) return parsed;
    }
    return INITIAL_CONTRACTS;
  });

  const [ots, setOts] = useState<OT[]>(() => {
    const local = localStorage.getItem('mafort_ots');
    if (local) {
      const parsed = JSON.parse(local);
      const isOld = parsed.some((o: any) => o.id === 'OT-4101' || o.id === 'OT-4102');
      if (!isOld && parsed.length <= 2) return parsed;
    }
    return INITIAL_OTS;
  });

  const [reports, setReports] = useState<TechnicalReport[]>(() => {
    const local = localStorage.getItem('mafort_reports');
    if (local) {
      const parsed = JSON.parse(local);
      const containsOldReports = parsed.some((r: any) => r.otId === 'OT-4103' || r.otId === 'OT-4104');
      if (!containsOldReports) return parsed;
    }
    return [];
  });

  // Offline buffer state queue
  const [offlineQueue, setOfflineQueue] = useState<TechnicalReport[]>(() => {
    const local = localStorage.getItem('mafort_offline_queue');
    return local ? JSON.parse(local) : [];
  });

  const [ordenesTrabajo, setOrdenesTrabajo] = useState<OrdenTrabajoLinea[]>(() => {
    const local = localStorage.getItem('mafort_ordenes_trabajo');
    if (local) {
      const parsed = JSON.parse(local);
      const containsOldData = parsed.some((o: any) => 
        o.razon_social?.includes('Repsol') || 
        o.razon_social?.includes('San Pablo') || 
        o.razon_social?.includes('Prosegur')
      );
      if (!containsOldData && parsed.length <= 2) return parsed;
    }
    return INITIAL_ORDENES_TRABAJO;
  });

  const [contratosNuevos, setContratosNuevos] = useState<Contrato[]>(() => {
    const local = localStorage.getItem('mafort_contratos_nuevos');
    if (local) {
      const parsed = JSON.parse(local);
      const containsOldData = parsed.some((c: any) => 
        c.cliente?.includes('Repsol') || 
        c.cliente?.includes('San Pablo') || 
        c.cliente?.includes('Prosegur')
      );
      if (!containsOldData && parsed.length <= 2) return parsed;
    }
    return INITIAL_CONTRATOS_NUEVOS;
  });

  const [targetVentas, setTargetVentas] = useState<TargetVentas[]>(() => {
    const local = localStorage.getItem('mafort_target_ventas');
    return local ? JSON.parse(local) : INITIAL_TARGET_VENTAS;
  });

  const [tipoCambio, setTipoCambio] = useState<number>(() => {
    const local = localStorage.getItem('mafort_tipo_cambio');
    return local ? Number(local) : 3.75;
  });

  useEffect(() => {
    localStorage.setItem('mafort_tipo_cambio', tipoCambio.toString());
  }, [tipoCambio]);

  // Sync state on change
  useEffect(() => {
    if (currentUser) {
      localStorage.setItem('mafort_current_user', JSON.stringify(currentUser));
    } else {
      localStorage.removeItem('mafort_current_user');
    }
  }, [currentUser]);

  useEffect(() => {
    localStorage.setItem('mafort_users', JSON.stringify(users));
  }, [users]);

  useEffect(() => {
    localStorage.setItem('mafort_user_logs', JSON.stringify(userLogs));
  }, [userLogs]);

  useEffect(() => {
    // Inject at least one unassigned OT if none exist (for testing "Operaciones")
    const hasUnassigned = ots.some(ot => ot.estado === OTStatus.CREADA || ot.estado === OTStatus.PENDIENTE_PROGRAMACION);
    if (!hasUnassigned) {
      const demoUnassigned: OT = {
        id: `OT-${Math.floor(5000 + Math.random() * 999)}`,
        clientId: 'client_2', // America Movil
        tipoMantenimiento: ServiceType.PREVENTIVO,
        tipoEquipo: EquipmentType.UPS,
        potenciaKva: 30,
        fechaProgramada: new Date().toISOString().split('T')[0],
        tecnicoTitular: '', // unassigned
        estado: OTStatus.CREADA
      };
      setOts(prev => [demoUnassigned, ...prev]);
    }
    localStorage.setItem('mafort_ots', JSON.stringify(ots));
  }, [ots]);

  useEffect(() => {
    localStorage.setItem('mafort_clients', JSON.stringify(clients));
  }, [clients]);

  useEffect(() => {
    localStorage.setItem('mafort_contracts', JSON.stringify(contracts));
  }, [contracts]);

  useEffect(() => {
    localStorage.setItem('mafort_ots', JSON.stringify(ots));
  }, [ots]);

  useEffect(() => {
    localStorage.setItem('mafort_reports', JSON.stringify(reports));
  }, [reports]);

  useEffect(() => {
    localStorage.setItem('mafort_ordenes_trabajo', JSON.stringify(ordenesTrabajo));
  }, [ordenesTrabajo]);

  // Local/offline sync between ordenesTrabajo (financial/billing cuotas) and ots (operational tasks)
  useEffect(() => {
    let changed = false;
    const updatedOts = [...ots];

    ordenesTrabajo.forEach((linea) => {
      if (linea.pendiente === 'POR EJECUTAR') {
        const otId = `OT-${linea.ot}`;
        const exists = updatedOts.some(ot => ot.id === otId || ot.otFinancieraId === linea.id);
        if (!exists) {
          // Find client matching razon_social
          let clientId = linea.clientId || '';
          if (!clientId && clients) {
            const matched = clients.find(c => c.razonSocial === linea.razon_social);
            if (matched) clientId = matched.id;
            else if (clients.length > 0) clientId = clients[0].id;
          }

          let tipoMantenimiento = ServiceType.PREVENTIVO;
          if (linea.tipo_venta === 'EMERGENCIA') {
            tipoMantenimiento = ServiceType.EMERGENCIA;
          } else if (linea.tipo_venta === 'REPARACION') {
            tipoMantenimiento = ServiceType.CORRECTIVO;
          }

          const newOt: OT = {
            id: otId,
            clientId: clientId,
            tipoMantenimiento: tipoMantenimiento,
            tipoEquipo: EquipmentType.UPS,
            potenciaKva: 30,
            fechaProgramada: linea.fecha || new Date().toISOString().split('T')[0],
            tecnicoTitular: '',
            estado: OTStatus.CREADA,
            otFinancieraId: linea.id
          };
          updatedOts.push(newOt);
          changed = true;
        } else {
          // Sync existing fields if they changed
          const idx = updatedOts.findIndex(ot => ot.id === otId || ot.otFinancieraId === linea.id);
          if (idx !== -1) {
            const existing = updatedOts[idx];
            let localChanged = false;
            
            let clientId = linea.clientId || '';
            if (!clientId && clients) {
              const matched = clients.find(c => c.razonSocial === linea.razon_social);
              if (matched) clientId = matched.id;
            }

            if (existing.clientId !== clientId && clientId) {
              existing.clientId = clientId;
              localChanged = true;
            }
            if (existing.fechaProgramada !== linea.fecha && linea.fecha) {
              existing.fechaProgramada = linea.fecha;
              localChanged = true;
            }
            let tipoMantenimiento = ServiceType.PREVENTIVO;
            if (linea.tipo_venta === 'EMERGENCIA') {
              tipoMantenimiento = ServiceType.EMERGENCIA;
            } else if (linea.tipo_venta === 'REPARACION') {
              tipoMantenimiento = ServiceType.CORRECTIVO;
            }
            if (existing.tipoMantenimiento !== tipoMantenimiento) {
              existing.tipoMantenimiento = tipoMantenimiento;
              localChanged = true;
            }
            if (!existing.otFinancieraId) {
              existing.otFinancieraId = linea.id;
              localChanged = true;
            }

            if (localChanged) {
              updatedOts[idx] = existing;
              changed = true;
            }
          }
        }
      } else if (linea.pendiente === 'ANULADO') {
        const otId = `OT-${linea.ot}`;
        const idx = updatedOts.findIndex(ot => ot.id === otId || ot.otFinancieraId === linea.id);
        if (idx !== -1) {
          updatedOts.splice(idx, 1);
          changed = true;
        }
      }
    });

    if (changed) {
      setOts(updatedOts);
    }
  }, [ordenesTrabajo, clients]);

  useEffect(() => {
    localStorage.setItem('mafort_contratos_nuevos', JSON.stringify(contratosNuevos));
  }, [contratosNuevos]);

  useEffect(() => {
    localStorage.setItem('mafort_target_ventas', JSON.stringify(targetVentas));
  }, [targetVentas]);

  useEffect(() => {
    localStorage.setItem('mafort_offline_queue', JSON.stringify(offlineQueue));
  }, [offlineQueue]);

  const fetchWithAuth = async (url: string, options: RequestInit = {}) => {
    const token = localStorage.getItem('mafort_jwt_token');
    const headers = {
      'Content-Type': 'application/json',
      ...(token ? { 'Authorization': `Bearer ${token}` } : {}),
      ...options.headers
    };
    const response = await fetch(url, { ...options, headers });
    if (response.status === 401) {
      localStorage.removeItem('mafort_jwt_token');
      localStorage.removeItem('mafort_current_user');
      setCurrentUser(null);
      throw new Error('Sesión expirada o inválida. Por favor inicie sesión.');
    }
    return response;
  };

  // Load from database on mount or login
  useEffect(() => {
    const loadFromBackend = async () => {
      try {
        console.log(">>> LOADING DATA FROM BACKEND. Current state size:", ordenesTrabajo.length);
        // Try to sync first to avoid overwriting local changes
        const syncSuccess = await handleSyncOffline();
        
        // If sync was successful, we can potentially skip fetching everything again
        // because handleSyncOffline already updated the state with the server's full DB state.
        if (syncSuccess) {
          console.log(">>> SYNC SUCCESSFUL. Skipping redundant fetch to avoid race conditions.");
          return;
        }

        console.log(">>> SYNC FAILED OR SKIPPED. Fetching state from server endpoints...");
        
        const [
          usersRes, logsRes, clientsRes, contractsRes, otsRes, reportsRes,
          otLineasRes, contratosComercialesRes, targetVentasRes, configRes
        ] = await Promise.all([
          fetchWithAuth('/api/users').then(res => res.json()),
          fetchWithAuth('/api/logs').then(res => res.json()),
          fetchWithAuth('/api/clients').then(res => res.json()),
          fetchWithAuth('/api/contracts').then(res => res.json()),
          fetchWithAuth('/api/ots').then(res => res.json()),
          fetchWithAuth('/api/reports').then(res => res.json()),
          fetchWithAuth('/api/ot-lineas').then(res => res.json()),
          fetchWithAuth('/api/contratos-comerciales').then(res => res.json()),
          fetchWithAuth('/api/target-ventas').then(res => res.json()),
          fetchWithAuth('/api/config').then(res => res.json())
        ]);

        if (Array.isArray(usersRes)) setUsers(usersRes);
        if (Array.isArray(logsRes)) setUserLogs(logsRes);
        if (Array.isArray(clientsRes)) setClients(clientsRes);
        if (Array.isArray(contractsRes)) setContracts(contractsRes);
        if (Array.isArray(otsRes)) setOts(otsRes);
        if (Array.isArray(reportsRes)) setReports(reportsRes);
        if (Array.isArray(otLineasRes)) setOrdenesTrabajo(otLineasRes);
        if (Array.isArray(contratosComercialesRes)) setContratosNuevos(contratosComercialesRes);
        if (Array.isArray(targetVentasRes)) setTargetVentas(targetVentasRes);
        if (configRes && typeof configRes.tipoCambio === 'number') setTipoCambio(configRes.tipoCambio);
      } catch (error) {
        console.error("Conexión local (utilizando caché local offline):", error);
      }
    };
    
    if (currentUser) {
      loadFromBackend();
    }

    // Auto-sync when coming back online
    const handleOnline = () => {
      console.log("Conexión restablecida. Iniciando sincronización...");
      handleSyncOffline();
    };

    window.addEventListener('online', handleOnline);
    return () => window.removeEventListener('online', handleOnline);
  }, [currentUser]);

  // Sync route on role switch
  useEffect(() => {
    if (currentUser) {
      const allowedRoles = ['Administrador', 'Ventas'];
      const userDefaultRole = currentUser.role === 'Cliente' ? 'Cliente' :
                               currentUser.role === 'Tecnico' ? 'Tecnico' :
                               currentUser.role === 'Supervisor' ? 'Supervisor' : 'Dashboard';
      
      if (!allowedRoles.includes(currentUser.role) && currentRole !== userDefaultRole && currentRole !== currentUser.role) {
        setCurrentRole(userDefaultRole as any);
      }
    }
  }, [currentUser, currentRole]);

  // DB Handlers
  const handleAddClient = async (newClient: Client) => {
    setClients(prev => [...prev, newClient]);
    try {
      await fetchWithAuth('/api/clients', {
        method: 'POST',
        body: JSON.stringify(newClient)
      });
    } catch (e) {
      console.warn("Cliente guardado en caché local:", e);
    }
  };

  const handleAddContract = async (newContract: Contract) => {
    setContracts(prev => [...prev, newContract]);
    try {
      await fetchWithAuth('/api/contracts', {
        method: 'POST',
        body: JSON.stringify(newContract)
      });
    } catch (e) {
      console.warn("Contrato guardado en caché local:", e);
    }
  };

  const handleAddOT = async (newOT: OT) => {
    setOts(prev => [...prev, newOT]);
    try {
      await fetchWithAuth('/api/ots', {
        method: 'POST',
        body: JSON.stringify(newOT)
      });
    } catch (e) {
      console.warn("OT guardada en caché local:", e);
    }
  };

  const syncFinancialLineWithOT = (otId: string, status: OTStatus, otFinancieraId?: string) => {
    if (status === OTStatus.APROBADA || status === OTStatus.FIRMADA) {
      setOrdenesTrabajo(prevLines => 
        prevLines.map(line => {
          const isMatch = line.id === otFinancieraId || 
                          line.ot === otId || 
                          String(line.ot) === String(otId).replace('OT-', '');
          if (isMatch) {
            // Append comment to history log if not already there
            const alreadyHasLog = line.estatus?.some(e => e.texto.includes("marcada como EJECUTADO")) || false;
            const newEstatus = [...(line.estatus || [])];
            if (!alreadyHasLog) {
              newEstatus.push({
                fecha: new Date().toISOString().split("T")[0],
                autor: "Sistema Automatizado",
                texto: `Aprobación o Firma registrada. OT Técnica ${otId} marcada como EJECUTADO y lista para facturar.`
              });
            }
            return {
              ...line,
              pendiente: 'EJECUTADO',
              estado: 'POR FACTURAR',
              listaParaFacturar: true,
              estatus: newEstatus
            };
          }
          return line;
        })
      );
    }
  };

  const handleUpdateOT = async (updatedOT: OT) => {
    setOts(prev => prev.map(o => o.id === updatedOT.id ? updatedOT : o));
    syncFinancialLineWithOT(updatedOT.id, updatedOT.estado, updatedOT.otFinancieraId);
    try {
      await fetchWithAuth(`/api/ots/${updatedOT.id}`, {
        method: 'PUT',
        body: JSON.stringify(updatedOT)
      });
    } catch (e) {
      console.warn("OT update guardado localmente:", e);
    }
  };

  const handleUpdateOtStatus = async (otId: string, status: OTStatus) => {
    let extraUpdates: Partial<OT> = {};
    if (status === OTStatus.TRABAJO_EN_EJECUCION) {
      const now = new Date();
      extraUpdates.horaInicioServicio = now.toTimeString().split(' ')[0].substring(0, 5); // "HH:MM"
    }
    
    setOts(prevOts => {
      const matched = prevOts.find(o => o.id === otId);
      if (matched) {
        syncFinancialLineWithOT(otId, status, matched.otFinancieraId);
      }
      return prevOts.map(o => o.id === otId ? { ...o, estado: status, ...extraUpdates } : o);
    });
    try {
      await fetchWithAuth(`/api/ots/${otId}`, {
        method: 'PUT',
        body: JSON.stringify({ estado: status, ...extraUpdates })
      });
    } catch (e) {
      console.warn("Estado de OT guardado localmente:", e);
    }
  };

  const handleAddReport = async (newReport: TechnicalReport) => {
    setReports(prev => {
      const filtered = prev.filter(r => r.otId !== newReport.otId);
      return [...filtered, newReport];
    });
    try {
      await fetchWithAuth('/api/reports', {
        method: 'POST',
        body: JSON.stringify(newReport)
      });
    } catch (e) {
      console.warn("Reporte guardado localmente:", e);
    }
  };

  const handleSaveReportOffline = (report: TechnicalReport) => {
    if (!isOnline) {
      setOfflineQueue([...offlineQueue, report]);
      setReports(prev => {
        const filtered = prev.filter(r => r.otId !== report.otId);
        return [...filtered, report];
      });
    } else {
      handleAddReport(report);
    }
  };

  const handleSyncOffline = async () => {
    // Collect all local data to sync
    const syncPayload = {
      reports: offlineQueue,
      ots: ots,
      clients: clients,
      contracts: contracts,
      ordenesTrabajo: ordenesTrabajo,
      contratosNuevos: contratosNuevos,
      users: users,
      logs: userLogs
    };
    
    console.log(">>> SYNCING TO SERVER:", syncPayload);
    
    try {
      const response = await fetchWithAuth('/api/sync', {
        method: 'POST',
        body: JSON.stringify(syncPayload)
      });
      const data = await response.json();
      if (data.success) {
        if (Array.isArray(data.reports)) setReports(data.reports);
        if (Array.isArray(data.ots)) setOts(data.ots);
        if (Array.isArray(data.clients)) setClients(data.clients);
        if (Array.isArray(data.contracts)) setContracts(data.contracts);
        if (Array.isArray(data.ordenesTrabajo)) setOrdenesTrabajo(data.ordenesTrabajo);
        if (Array.isArray(data.contratosNuevos)) setContratosNuevos(data.contratosNuevos);
        if (Array.isArray(data.users)) setUsers(data.users);
        if (Array.isArray(data.logs)) setUserLogs(data.logs);
        
        setOfflineQueue([]);
        console.log("Sincronización completa con el servidor exitosa.");
        return true;
      }
    } catch (error) {
      console.error("Fallo de conexión remota durante la sincronización:", error);
    }

    // Fallback logic for reports if server is still down
    let updatedOts = [...ots];
    const syncedReports = offlineQueue.map(r => {
      updatedOts = updatedOts.map(o => o.id === r.otId ? { ...o, estado: OTStatus.EN_REVISION } : o);
      return { ...r, offlineDirty: false };
    });

    if (syncedReports.length > 0) {
      setReports(prev => {
        const nonSyncedOtsOfQueue = syncedReports.map(sr => sr.otId);
        const filteredPrev = prev.filter(p => !nonSyncedOtsOfQueue.includes(p.otId));
        return [...filteredPrev, ...syncedReports];
      });
      setOts(updatedOts);
      setOfflineQueue([]);
      alert(`🤝 COLA DE SINCRONIZACIÓN LOCAL: Se guardaron ${syncedReports.length} informes en el historial local.`);
    }
    
    return false;
  };

  const handleAddUser = async (user: User) => {
    setUsers(prev => [...prev, user]);
    try {
      await fetchWithAuth('/api/users', {
        method: 'POST',
        body: JSON.stringify(user)
      });
    } catch (e) {
      console.warn("Usuario guardado en local:", e);
    }
  };

  const handleUpdateUser = async (userId: string, updated: Partial<User>) => {
    setUsers(prev => prev.map(u => u.id === userId ? { ...u, ...updated } : u));
    
    if (currentUser && currentUser.id === userId) {
      setCurrentUser(prev => prev ? { ...prev, ...updated } : null);
    }

    try {
      await fetchWithAuth(`/api/users/${userId}`, {
        method: 'PUT',
        body: JSON.stringify(updated)
      });
    } catch (e) {
      console.warn("Cambios guardados localmente:", e);
    }
  };

  const handleAddLog = async (log: UserActivityLog) => {
    setUserLogs(prev => [log, ...prev]);
    try {
      await fetchWithAuth('/api/logs', {
        method: 'POST',
        body: JSON.stringify(log)
      });
    } catch (e) {
      console.warn("Bitácora guardada en local:", e);
    }
  };

  const handleDeleteUser = async (userId: string) => {
    const userToDelete = users.find(u => u.id === userId);
    setUsers(prev => prev.filter(u => u.id !== userId));

    const newAuditLog: UserActivityLog = {
      id: `log_${Date.now()}`,
      timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
      userEmail: currentUser ? currentUser.email : 'sistema',
      action: 'ELIMINAR_USUARIO',
      details: `Baja permanente del operador [${userToDelete?.username || userId}]`,
      ipAddress: '192.168.10.15'
    };
    handleAddLog(newAuditLog);

    try {
      await fetchWithAuth(`/api/users/${userId}`, {
        method: 'DELETE'
      });
    } catch (e) {
      console.warn("Usuario eliminado localmente:", e);
    }
  };

  // FINANCIAL / OPERATIONS HANDLERS FOR ORDENESTRABAJOVIEW
  const handleAddOtLinea = async (linea: OrdenTrabajoLinea) => {
    setOrdenesTrabajo(prev => [linea, ...prev]);
    try {
      await fetchWithAuth('/api/ot-lineas', {
        method: 'POST',
        body: JSON.stringify(linea)
      });
    } catch (e) {
      console.warn("Línea OT guardada localmente:", e);
    }
  };

  const handleUpdateOtLinea = async (updated: OrdenTrabajoLinea) => {
    setOrdenesTrabajo(prev => prev.map(l => {
      if (l.id === updated.id) {
        return updated;
      }
      if (l.ot_marco === updated.ot_marco) {
        return {
          ...l,
          razon_social: updated.razon_social,
          empresa: updated.empresa,
          n_cotizacion: updated.n_cotizacion,
          n_oc_os: updated.n_oc_os,
          descripcion: updated.descripcion,
          simbolo_moneda: updated.simbolo_moneda,
          monto_marco_sin_igv: updated.monto_marco_sin_igv,
          monto_marco_inc_igv: updated.monto_marco_inc_igv,
          comercial: updated.comercial,
        };
      }
      return l;
    }));
    try {
      await fetchWithAuth(`/api/ot-lineas/${updated.id}`, {
        method: 'PUT',
        body: JSON.stringify(updated)
      });
    } catch (e) {
      console.warn("Línea OT actualizada localmente:", e);
    }
  };

  const handleAddContratoComercial = async (newContrato: any) => {
    setContratosNuevos(prev => [newContrato, ...prev]);
    try {
      await fetchWithAuth('/api/contratos-comerciales', {
        method: 'POST',
        body: JSON.stringify(newContrato)
      });
    } catch (e) {
      console.warn("Contrato comercial guardado localmente:", e);
    }
  };

  const handleUpdateContratoComercial = async (updated: any) => {
    setContratosNuevos(prev => prev.map(c => c.id === updated.id ? updated : c));
    try {
      await fetchWithAuth(`/api/contratos-comerciales/${updated.id}`, {
        method: 'PUT',
        body: JSON.stringify(updated)
      });
    } catch (e) {
      console.warn("Contrato comercial actualizado localmente:", e);
    }
  };

  const handleUpdateTipoCambio = async (val: number) => {
    setTipoCambio(val);
    try {
      await fetchWithAuth('/api/config', {
        method: 'POST',
        body: JSON.stringify({ tipoCambio: val })
      });
    } catch (e) {
      console.warn("Tipo de cambio guardado localmente:", e);
    }
  };

  // Render LoginView if unauthorized
  if (!currentUser) {
    return (
      <LoginView 
        users={users}
        onLoginSuccess={(user) => {
          const newAuditLog: UserActivityLog = {
            id: `log_${Date.now()}`,
            timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
            userEmail: user.email,
            action: 'INICIO_SESION',
            details: `Ingreso validado al portal. Rol asignado: ${user.role}`,
            ipAddress: '192.168.10.15'
          };
          
          setUsers(prev => prev.map(u => {
            if (u.id === user.id) {
              return { ...u, ultimoIngreso: newAuditLog.timestamp };
            }
            return u;
          }));

          handleAddLog(newAuditLog);
          setCurrentUser({ ...user, ultimoIngreso: newAuditLog.timestamp });
          const defaultRole = user.role === 'Cliente' ? 'Cliente' :
                              user.role === 'Tecnico' ? 'Tecnico' :
                              user.role === 'Supervisor' ? 'Supervisor' :
                              user.role === 'Ventas' ? 'Ventas' : 'Dashboard';
          setCurrentRole(defaultRole as any);
        }} 
      />
    );
  }

  // Count active stats (filtered if the user has role 'Cliente')
  const statsOts = currentUser?.role === 'Cliente' && currentUser?.clientId
    ? ots.filter(o => o.clientId === currentUser.clientId)
    : ots;
  const otsEnProceso = statsOts.filter(o => o.estado === OTStatus.TRABAJO_EN_EJECUCION || o.estado === OTStatus.PROGRAMADA).length;
  const otsRevision = statsOts.filter(o => o.estado === OTStatus.EN_REVISION).length;
  const otsAprobadas = statsOts.filter(o => o.estado === OTStatus.APROBADA || o.estado === OTStatus.FIRMADA).length;

  return (
    <div className="min-h-[100dvh] bg-[#EAEFEB] flex font-sans text-slate-800" id="mafort-app-wrapper">
      
      {/* 1. LEFT SIDEBAR (Sticky full-height pane) */}
      <aside className={`bg-white flex flex-col justify-between shrink-0 h-[100dvh] sticky top-0 transition-all duration-300 ease-in-out ${isSidebarOpen ? 'w-[260px] border-r border-slate-100/80 shadow-[0_10px_30px_rgba(148,163,184,0.04)]' : 'w-0 border-r-0 overflow-hidden'}`} id="sidebar-panel">
        <div className="flex flex-col pt-6 px-4">
          
          {/* Sidebar Header / Brand */}
          <div className="flex items-center gap-3 mb-8 px-2 select-none">
            <div className="w-10 h-10 rounded-2xl bg-[#00B594] flex items-center justify-center text-white font-black text-lg shadow-[0_4px_12px_rgba(0,181,148,0.25)]">
              <Activity className="text-white" size={20} strokeWidth={2.5} />
            </div>
            <div className="text-left">
              <h2 className="text-sm font-black text-slate-900 tracking-tight leading-none">
                TeamHub
              </h2>
              <span className="text-[9px] font-black text-[#94A3B8] font-mono tracking-wider mt-1 block">
                MAFORT CONECTADO
              </span>
            </div>
          </div>

          {/* Navigation Items */}
          <nav className="space-y-1">
            {APP_MODULES.filter(link => {
              if (currentUser.allowedModules && currentUser.allowedModules.length > 0) {
                return currentUser.allowedModules.includes(link.id);
              }
              if (currentUser.role === 'Administrador') return true;
              if (link.id === 'GestionOTs' || link.id === 'ClientesContratos') {
                return currentUser.role === 'Ventas';
              }
              if (link.id === 'Usuarios') {
                return currentUser.role === 'Administrador';
              }
              return link.id === 'Dashboard' || link.id === 'Monitoreo' || link.id === currentUser.role;
            }).map((link) => {
              const isSelected = currentRole === link.id || (link.id === 'Usuarios' && currentRole === 'Usuarios');
              return (
                <button
                  key={link.id}
                  onClick={() => setCurrentRole(link.id as any)}
                  className={`w-full flex items-center justify-between px-3.5 py-2.5 rounded-2xl text-xs font-bold transition-all text-left cursor-pointer group ${
                    isSelected 
                      ? '!bg-[#00B594] !text-white shadow-[0_4px_14px_rgba(0,181,148,0.22)]' 
                      : 'text-slate-600 hover:text-slate-900 hover:bg-slate-50/80'
                  }`}
                  style={isSelected ? { backgroundColor: '#00B594', color: '#ffffff' } : undefined}
                >
                  <div className="flex items-center gap-3">
                    <span className={`${isSelected ? '!text-white' : link.iconColor} shrink-0`}>
                      {link.icon}
                    </span>
                    <span className={isSelected ? '!text-white' : 'text-slate-700 font-medium'}>{link.displayLabel}</span>
                  </div>
                  {link.badge(isSelected)}
                </button>
              );
            })}
          </nav>

        </div>

        {/* Sidebar Bottom: Logout */}
        <div className="p-4 border-t border-slate-100/80">
          <button
            onClick={() => setShowLogoutConfirm(true)}
            className="w-full flex items-center gap-3 px-3.5 py-2.5 rounded-xl text-xs font-bold text-rose-500 hover:bg-rose-50/50 transition-all cursor-pointer text-left"
          >
            <LogOut size={16} className="text-rose-500 shrink-0" />
            <span>Cerrar Sesión (Salir)</span>
          </button>
        </div>

      </aside>

      {/* 2. MAIN VIEW AREA (Right Pane) */}
      <div className="flex-1 flex flex-col min-w-0 h-[100dvh] overflow-hidden animate-fade-in" id="main-view-pane">
        
        {/* Header Bar */}
        <header className="h-[64px] bg-white border-b border-slate-100/80 px-6 flex items-center justify-between shrink-0" id="header-bar">
          
          <div className="flex items-center gap-4 flex-1 max-w-xl">
            {/* Hamburger menu */}
            <button 
              onClick={() => setIsSidebarOpen(!isSidebarOpen)}
              className="w-9 h-9 rounded-xl border border-slate-200 flex items-center justify-center text-slate-500 hover:bg-slate-50 cursor-pointer shrink-0"
              title={isSidebarOpen ? "Ocultar menú" : "Mostrar menú"}
            >
              <Menu size={16} />
            </button>

            {/* Search Input bar */}
            <div className="relative w-full max-w-md">
              <Search className="absolute left-3.5 top-2.5 text-slate-400" size={14} />
              <input
                type="text"
                placeholder="Buscar órdenes de UPS, contratos, SLAs..."
                className="w-full bg-[#F3F4F6] border border-transparent hover:border-slate-300 focus:border-slate-300 rounded-full pl-10 pr-4 py-2 text-xs text-slate-800 placeholder-slate-400 focus:outline-none transition-all font-sans"
              />
            </div>
          </div>

          {/* Connected/Offline toggles, profile & notifications */}
          <div className="flex items-center gap-4 shrink-0">
            
            {/* Connectivity Pill with controllers */}
            <div className="flex items-center bg-slate-100 rounded-full p-0.5 border border-slate-200/50">
              <button
                type="button"
                onClick={() => {
                  setIsOnline(true);
                  handleAddLog({
                    id: `log_${Date.now()}`,
                    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
                    userEmail: currentUser.email,
                    action: 'EDITAR_USUARIO',
                    details: 'Sincronizador en la nube activado.',
                    ipAddress: '127.0.0.1'
                  });
                }}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
                  isOnline ? 'bg-[#10B981] text-white shadow-2xs' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <Wifi size={10} />
                <span>Conectado</span>
              </button>
              <button
                type="button"
                onClick={() => {
                  setIsOnline(false);
                  handleAddLog({
                    id: `log_${Date.now()}`,
                    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
                    userEmail: currentUser.email,
                    action: 'EDITAR_USUARIO',
                    details: 'Simulación de desconexión sin señal Wifi activada.',
                    ipAddress: '127.0.0.1'
                  });
                }}
                className={`flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-bold transition-all cursor-pointer ${
                  !isOnline ? 'bg-slate-500 text-white shadow-2xs' : 'text-slate-400 hover:text-slate-600'
                }`}
              >
                <WifiOff size={10} />
                <span>Offline</span>
              </button>
            </div>

            {/* Offline reports sync alert */}
            {offlineQueue.length > 0 && (
              <button
                onClick={handleSyncOffline}
                className="bg-amber-500 hover:bg-amber-600 text-slate-900 px-3 py-1 rounded-lg text-[10px] font-mono font-black flex items-center gap-1 animate-pulse shrink-0 cursor-pointer"
              >
                <RefreshCw size={10} />
                <span>Sync {offlineQueue.length}</span>
              </button>
            )}

            {/* Notification bell and logout */}
            <div className="flex items-center gap-2 text-slate-400">
              <button 
                type="button"
                onClick={() => alert(`🔔 Notificaciones de SLA Mafort: Cuenta con ${otsRevision} órdenes de trabajo pendientes de firma o revisión en el servidor.`)}
                className="p-1.5 bg-white hover:bg-slate-50 text-slate-500 rounded-lg border border-slate-200 relative hover:text-slate-700 cursor-pointer"
              >
                <Bell size={14} />
                <span className="absolute top-1 right-1 w-1.5 h-1.5 bg-amber-500 rounded-full"></span>
              </button>
            </div>

            {/* Profile capsule */}
            <div className="flex items-center gap-3">
              <div className="text-right leading-none hidden sm:block select-none">
                <span className="font-extrabold text-slate-850 text-xs block leading-tight">
                  {currentUser.username}
                </span>
                <span className="text-[9px] text-[#10B981] font-extrabold tracking-wider block mt-0.5 uppercase font-sans">
                  {currentUser.role === 'Usuarios' ? 'SEGURIDAD' : currentUser.role.toUpperCase()} •
                </span>
              </div>
              
              <div className="w-9 h-9 rounded-full bg-[#EBF7F2] border border-[#10B981]/20 flex items-center justify-center text-[#10B981] font-black text-xs select-none">
                {currentUser.username.substring(0, 2).toUpperCase()}
              </div>

              {/* Logout button */}
              <button 
                onClick={() => setShowLogoutConfirm(true)}
                className="w-8 h-8 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400 hover:text-rose-500 hover:bg-rose-50 cursor-pointer transition-colors"
                title="Cerrar Sesión"
              >
                <LogOut size={14} />
              </button>
            </div>

          </div>

        </header>

        {/* Scrollable Work Area Content */}
        <main className="flex-1 overflow-y-auto p-6 bg-[#EAEFEB]" id="main-workspace-content">
          
          <div className="max-w-[1400px] mx-auto space-y-6">
            
            {/* 1. MAIN INTEGRATED DASHBOARD VIEW */}
            {currentRole === 'Dashboard' && (
              <div className="space-y-6" id="dashboard-tab-subpanel">
                
                {/* SLA METRIC COUNTER CARDS (TOP ROW OF FOUR) */}
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 text-left">
                  
                  {/* Card 1: SLA TOTAL OTS */}
                  <div className="bg-white rounded-[24px] border border-slate-100 p-5 flex items-center justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)] teamhub-card-shadow">
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block font-mono">SLA Total OTs</span>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="text-2xl font-black text-slate-900 leading-none">5</span>
                        <span className="text-[10.5px] text-slate-400 font-bold leading-none font-sans">programadas</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Mantenimiento de UPS en curso</p>
                    </div>
                    <CircularProgress value={14} total={20} color="#00B594" />
                  </div>

                  {/* Card 2: VISITAS ANUALES */}
                  <div className="bg-white rounded-[24px] border border-slate-100 p-5 flex items-center justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)] teamhub-card-shadow">
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block font-mono">Visitas Anuales</span>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="text-2xl font-black text-slate-900 leading-none">11</span>
                        <span className="text-[10.5px] text-slate-400 font-bold leading-none font-sans">totales</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Soportado en contrato SLA</p>
                    </div>
                    <CircularProgress value={10} total={15} color="#F59E0B" />
                  </div>

                  {/* Card 3: SATISFACCIÓN CLIENTE */}
                  <div className="bg-white rounded-[24px] border border-slate-100 p-5 flex items-center justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)] teamhub-card-shadow">
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block font-mono">Satisfacción Cliente</span>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="text-2xl font-black text-slate-900 leading-none">92%</span>
                        <span className="text-[10.5px] text-[#00B594] font-bold leading-none font-sans">SLA OK</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Basado en firmas validadas</p>
                    </div>
                    <CircularProgress value={92} total={100} label="92%" color="#00B594" />
                  </div>

                  {/* Card 4: BYPASS ACTIVO */}
                  <div className="bg-white rounded-[24px] border border-slate-100 p-5 flex items-center justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)] teamhub-card-shadow">
                    <div className="space-y-1.5">
                      <span className="text-[10px] font-extrabold uppercase tracking-wider text-slate-400 block font-mono">Bypass Activo</span>
                      <div className="flex items-baseline gap-1 mt-1">
                        <span className="text-2xl font-black text-slate-900 leading-none">1</span>
                        <span className="text-[10.5px] text-rose-500 font-bold leading-none font-sans">Crítico</span>
                      </div>
                      <p className="text-[11px] text-slate-400">Requiere auditoría inmediata</p>
                    </div>
                    <CircularProgress value={3} total={14} color="#F43F5E" />
                  </div>

                </div>

                <>
                    {/* OPERATIONAL DISTRIBUTION GRID */}
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 text-left">
                      
                      {/* Left and Middle columns (OperationalPerformanceChart - taking 2/3 wide grid space) */}
                      <div className="lg:col-span-2">
                        <OperationalPerformanceChart />
                      </div>

                      {/* Right column (TechHoursChart - taking 1/3 wide grid space) */}
                      <div className="lg:col-span-1">
                        <TechHoursChart />
                      </div>

                    </div>

                    {/* THREE-COLUMN CARDS ROW (Bottom panel section) */}
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 text-left">
                      
                      {/* Column 1: SLA Operador en Turno */}
                      <div className="bg-white border border-slate-100 rounded-[24px] p-6 flex flex-col justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)] teamhub-card-shadow">
                        <div>
                          <h4 className="text-sm font-extrabold text-slate-900 tracking-tight mb-4">SLA Operador en Turno</h4>
                          <div className="flex items-center gap-4 bg-slate-50 border border-slate-100 p-4 rounded-2xl">
                            <div className="w-12 h-12 rounded-full bg-slate-100 border border-slate-200/40 flex items-center justify-center text-slate-600 font-extrabold text-base select-none">
                              {currentUser.username.substring(0, 2).toUpperCase()}
                            </div>
                            <div className="text-left space-y-0.5">
                              <h5 className="font-extrabold text-slate-800 text-sm leading-tight">{currentUser.username}</h5>
                              <p className="text-[11px] text-slate-400 font-mono">{currentUser.email}</p>
                            </div>
                          </div>
                        </div>

                        <div className="mt-6 pt-4 border-t border-slate-100 space-y-3 text-xs">
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-400 font-mono text-[9.5px] uppercase tracking-wider">Rol de Seguridad</span>
                            <span className="font-black text-[#00B594] font-mono">{currentUser.role === 'Usuarios' ? 'Seguridad' : currentUser.role}</span>
                          </div>
                          <div className="flex items-center justify-between">
                            <span className="font-bold text-slate-400 font-mono text-[9.5px] uppercase tracking-wider">Área Operativa</span>
                            <span className="font-black text-slate-700 font-mono">{currentUser.role ? getAreaOperativa(currentUser.role) : 'Administración'}</span>
                          </div>
                        </div>
                      </div>

                      {/* Column 2: Documentos & SLAs */}
                      <div className="bg-white border border-slate-100 rounded-[24px] p-6 flex flex-col justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)] teamhub-card-shadow">
                        <div>
                          <div className="flex items-center justify-between mb-4">
                            <h4 className="text-sm font-extrabold text-slate-900 tracking-tight">Documentos & SLAs</h4>
                            <span className="text-[10px] font-black text-[#00B594] font-mono bg-[#E6F7F4] px-2 py-0.5 rounded-md">3 Certificados</span>
                          </div>
                          
                          <div className="space-y-3">
                            {[
                              { name: 'SLA-Prosegur-Contrato.pdf', details: '1.24 MB • Impreso 12 Ene 2026' },
                              { name: 'Certificado-Calibracion-UPS.pdf', details: '895 KB • Impreso 21 Mar 2026' },
                              { name: 'Manual-Bypass-Termico-Mafort.pdf', details: '3.68 MB • Impreso 04 May 2026' }
                            ].map((doc, idx) => (
                              <div key={idx} className="flex items-center justify-between p-2 bg-slate-50 border border-slate-100 rounded-xl hover:bg-slate-100/50 transition-all">
                                <div className="flex items-center gap-3 min-w-0">
                                  <div className="w-8.5 h-8.5 rounded-lg bg-[#E6F7F4] text-[#00B594] flex items-center justify-center shrink-0">
                                    <FileText size={14} />
                                  </div>
                                  <div className="text-left min-w-0">
                                    <span className="font-bold text-slate-850 text-xs block truncate leading-none mb-1">{doc.name}</span>
                                    <span className="text-[9.5px] text-slate-400 block font-mono">{doc.details}</span>
                                  </div>
                                </div>
                                <button className="p-1 text-slate-400 hover:text-slate-600 cursor-pointer">
                                  <ArrowUpRight size={13} />
                                </button>
                              </div>
                            ))}
                          </div>
                        </div>
                      </div>

                      {/* Column 3: Notas de Auditoría Interna */}
                      <div className="bg-white border border-slate-100 rounded-[24px] p-6 flex flex-col justify-between shadow-[0_8px_30px_rgb(0,0,0,0.015)] teamhub-card-shadow">
                        <div>
                          <h4 className="text-sm font-extrabold text-slate-900 tracking-tight mb-4">Notas de Auditoría Interna</h4>
                          
                          <div className="space-y-3.5">
                            <div className="border-l-4 border-[#F59E0B] bg-[#FEF3C7]/20 p-3.5 rounded-r-2xl">
                              <span className="text-[9px] font-black text-[#D97706] tracking-wide block uppercase font-mono mb-1">Promedio Retomado</span>
                              <p className="text-[11px] font-semibold text-slate-600 leading-normal">
                                Se ha re-establecido el bypass térmico de Clínica San Pablo. Técnico asistió con kit certificado v2.
                              </p>
                            </div>
                            <div className="border-l-4 border-[#3B82F6] bg-[#EFF6FF]/30 p-3.5 rounded-r-2xl">
                              <span className="text-[9px] font-black text-[#2563EB] tracking-wide block uppercase font-mono mb-1">Seguridad Criptográfica</span>
                              <p className="text-[11px] font-semibold text-slate-600 leading-normal">
                                Cuentas suspendidas preventivamente quedan sin acceso alguno en los módulos de Técnico y Cliente de forma automática.
                              </p>
                            </div>
                          </div>
                        </div>
                      </div>

                    </div>

                    {/* ACCESO RÁPIDO A OTS (DASHBOARD TABLE INDICATOR) */}
                    <div className="bg-white rounded-[24px] border border-slate-200/60 p-6 md:p-8 shadow-[0_8px_30px_rgb(0,0,0,0.02)] text-left space-y-6">
                      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-2">
                        <div>
                          <h4 className="text-sm font-extrabold text-slate-900 tracking-tight">Acceso Rápido a Órdenes de Trabajo (OTs)</h4>
                          <p className="text-xs text-slate-400 font-medium mt-1">
                            Mostrando las 10 órdenes más cercanas a la fecha actual. Seleccione los módulos operativos en el menú izquierdo para ver e interactuar con todas las órdenes.
                          </p>
                        </div>
                        <div className="text-[11px] font-mono font-bold text-slate-500 bg-slate-50 px-4 py-1.5 rounded-full border border-slate-200 shrink-0">
                          Total en Base de Datos: <strong className="text-slate-800">{ots.length} OTs</strong>
                        </div>
                      </div>

                      <div className="overflow-x-auto">
                        <table className="w-full text-left border-collapse text-xs">
                          <thead>
                            <tr className="border-b border-slate-150 text-slate-400 font-mono text-[10px] uppercase">
                              <th className="py-3 pr-3 font-bold">ID Orden</th>
                              <th className="py-3 px-3 font-bold">Cliente</th>
                              <th className="py-3 px-3 font-bold">Equipo</th>
                              <th className="py-3 px-3 font-bold">Potencia</th>
                              <th className="py-3 px-3 font-bold">Técnico Titular</th>
                              <th className="py-3 px-3 font-bold">Fecha Programada</th>
                              <th className="py-3 pl-3 text-right font-bold">Estado Actual</th>
                            </tr>
                          </thead>
                          <tbody className="divide-y divide-slate-100">
                            {(() => {
                              const todayTime = new Date().setHours(0, 0, 0, 0);
                              const d = new Date();
                              const year = d.getFullYear();
                              const month = String(d.getMonth() + 1).padStart(2, '0');
                              const day = String(d.getDate()).padStart(2, '0');
                              const todayString = `${year}-${month}-${day}`;

                              const closestOts = [...ots]
                                .sort((a, b) => {
                                  const timeA = new Date(a.fechaProgramada).getTime();
                                  const timeB = new Date(b.fechaProgramada).getTime();
                                  return Math.abs(timeA - todayTime) - Math.abs(timeB - todayTime);
                                })
                                .slice(0, 10);

                              return closestOts.map((ot) => {
                                const clObj = clients.find(c => c.id === ot.clientId);
                                
                                // Determinar estado y clase dinámicamente
                                let statusText = ot.estado as string;
                                let statusClass = 'border border-sky-400 text-sky-700 bg-sky-50/30';

                                if (ot.fechaProgramada > todayString) {
                                  statusText = 'Visita pendiente';
                                  statusClass = 'border border-slate-300 text-slate-500 bg-slate-50/50';
                                } else if (ot.estado === OTStatus.EN_REVISION) {
                                  statusText = 'En proceso de aprobación por el supervisor';
                                  statusClass = 'bg-[#FFFBEB] text-[#D97706] border border-[#FCD34D]';
                                } else if (ot.estado === OTStatus.PROGRAMADA) {
                                  statusText = 'Visita Programada';
                                  statusClass = 'border border-slate-300 text-slate-700 bg-slate-50/20';
                                } else if (ot.estado === OTStatus.TRABAJO_EN_EJECUCION) {
                                  statusText = 'Trabajo en Ejecución';
                                  statusClass = 'border border-blue-300 text-blue-700 bg-blue-50/20';
                                } else if (ot.estado === OTStatus.OBSERVADA) {
                                  statusText = 'Rechazado (Requiere Corrección)';
                                  statusClass = 'border border-rose-300 text-rose-700 bg-rose-50/20';
                                } else if (ot.estado === OTStatus.APROBADA) {
                                  statusText = 'Aprobado por Proyectos';
                                  statusClass = 'border border-emerald-400 text-emerald-700 bg-emerald-50/30';
                                } else if (ot.estado === OTStatus.FIRMADA) {
                                  statusText = 'Conformidad Firmada';
                                  statusClass = 'border border-emerald-500 text-emerald-800 bg-emerald-100/40';
                                }

                                return (
                                  <tr key={ot.id} className="hover:bg-slate-50/50 transition-colors">
                                    <td className="py-4 pr-3 font-bold text-[#10B981]">{ot.id}</td>
                                    <td className="py-4 px-3 font-extrabold text-slate-900">{clObj?.razonSocial || "Cliente Corporativo"}</td>
                                    <td className="py-4 px-3 text-slate-600 font-medium">{ot.tipoEquipo}</td>
                                    <td className="py-4 px-3 font-mono font-bold text-slate-500">{ot.potenciaKva} KVA</td>
                                    <td className="py-4 px-3 text-slate-700 font-semibold">{ot.tecnicoTitular}</td>
                                    <td className="py-4 px-3 font-mono font-bold text-[#10B981]">{ot.fechaProgramada.split('-').reverse().join('/')}</td>
                                    <td className="py-4 pl-3 text-right">
                                      <span className={`inline-block px-3 py-1 rounded-full text-[11px] font-bold ${statusClass}`}>
                                        {statusText}
                                      </span>
                                    </td>
                                  </tr>
                                );
                              });
                            })()}
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </>

              </div>
            )}

            {/* 1.5 MONITOREO DE TÉCNICOS VIEW MODULE */}
            {currentRole === 'Monitoreo' && (
              <div className="bg-white rounded-3xl border border-slate-200/60 p-6 md:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.02)]">
                <TechMonitoringDashboard 
                  ots={ots}
                  clients={clients}
                  reports={reports}
                  onUpdateOtStatus={handleUpdateOtStatus}
                  onUpdateOt={handleUpdateOT}
                />
              </div>
            )}

            {/* 1.8 GESTIÓN DE OTS VIEW MODULE (SLA / Finanzas) */}
            {currentRole === 'GestionOTs' && (currentUser?.role === 'Administrador' || currentUser?.role === 'Ventas') && (
              <div className="bg-white rounded-3xl border border-slate-200/60 p-6 md:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.02)]">
                <OrdenesTrabajoView
                  lineas={ordenesTrabajo}
                  clients={clients}
                  targetVentas={targetVentas}
                  currentUser={{ email: currentUser?.email || 'admin@mafort.com', username: currentUser?.username || 'Administrador' }}
                  onAddLinea={handleAddOtLinea}
                  onUpdateLinea={handleUpdateOtLinea}
                  tipoCambio={tipoCambio}
                  onUpdateTipoCambio={handleUpdateTipoCambio}
                  ots={ots}
                  reports={reports}
                />
              </div>
            )}

            {/* 1.9 CLIENTES Y CONTRATOS VIEW MODULE */}
            {currentRole === 'ClientesContratos' && (currentUser?.role === 'Administrador' || currentUser?.role === 'Ventas') && (
              <div className="bg-white rounded-3xl border border-slate-200/60 p-6 md:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.02)]">
                <ClientesContratosView
                  clients={clients}
                  contratos={contratosNuevos}
                  users={users}
                  currentUser={{ email: currentUser?.email || 'admin@mafort.com', username: currentUser?.username || 'Administrador' }}
                  onAddClient={handleAddClient}
                  onAddContrato={handleAddContratoComercial}
                  onUpdateContrato={handleUpdateContratoComercial}
                />
              </div>
            )}

            {/* 2. VENTAS VIEW MODULE */}
            {currentRole === 'Ventas' && (
              <div className="bg-white rounded-3xl border border-slate-200/60 p-6 md:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.02)]">
                <VentasView 
                  clients={clients}
                  contracts={contracts}
                  ots={ots}
                  reports={reports}
                  onAddClient={handleAddClient}
                  onAddContract={handleAddContract}
                  onAddOT={handleAddOT}
                  onUpdateOT={handleUpdateOT}
                />
              </div>
            )}

            {/* 3. TÉCNICO VIEW MODULE */}
            {currentRole === 'Tecnico' && (
              <div className="bg-white rounded-3xl border border-slate-200/60 p-6 md:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.02)]">
                <TecnicoView 
                  ots={ots}
                  clients={clients}
                  reports={reports}
                  isOnline={isOnline}
                  onSaveReportOffline={handleSaveReportOffline}
                  onUpdateOtStatus={handleUpdateOtStatus}
                  onAddOT={handleAddOT}
                  currentUser={currentUser}
                />
              </div>
            )}

            {/* 4. SUPERVISOR VIEW MODULE */}
            {currentRole === 'Supervisor' && (
              <div className="bg-white rounded-3xl border border-slate-200/60 p-6 md:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.02)]">
                <SupervisorView 
                  ots={ots}
                  clients={clients}
                  reports={reports}
                  onUpdateOtStatus={handleUpdateOtStatus}
                  onUpdateReport={(updatedRep) => {
                    setReports(prev => prev.map(r => r.id === updatedRep.id ? updatedRep : r));
                  }}
                />
              </div>
            )}

            {/* 5. CLIENTE VIEW MODULE */}
            {currentRole === 'Cliente' && (
              <div className="bg-white rounded-3xl border border-slate-200/60 p-6 md:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.02)]">
                <ClienteView 
                  ots={ots}
                  clients={clients}
                  reports={reports}
                  onUpdateOtStatus={handleUpdateOtStatus}
                  onUpdateReport={(updatedRep) => {
                    setReports(prev => prev.map(r => r.otId === updatedRep.otId ? updatedRep : r));
                  }}
                />
              </div>
            )}

            {/* 6. SEGURIDAD & OPERADORES VIEW MODULE */}
            {currentRole === 'Usuarios' && (
              <div className="bg-white rounded-3xl border border-slate-200/60 p-6 md:p-8 shadow-[0_10px_40px_rgba(0,0,0,0.02)]">
                <UserManagementView 
                  users={users}
                  logs={userLogs}
                  currentUser={currentUser}
                  onAddUser={handleAddUser}
                  onUpdateUser={handleUpdateUser}
                  onAddLog={handleAddLog}
                  onDeleteUser={handleDeleteUser}
                />
              </div>
            )}

          </div>

        </main>

      </div>

      {/* SANDBOX-SAFE LOGOUT CONFIRMATION MODAL OVERLAY */}
      {showLogoutConfirm && (
        <div className="fixed inset-0 z-[9999] flex items-center justify-center bg-slate-900/60 backdrop-blur-xs p-4 animate-fade-in text-slate-800 font-sans" id="logout-confirmation-modal">
          <div className="bg-white border border-slate-200 w-full max-w-sm rounded-2xl p-5 shadow-2xl space-y-4 text-left">
            <div className="flex items-center gap-3 pb-2 border-b border-slate-100">
              <div className="w-10 h-10 rounded-full bg-rose-50 border border-rose-100 flex items-center justify-center text-rose-500 shrink-0">
                <LogOut size={18} />
              </div>
              <div>
                <h4 className="font-bold text-slate-850 text-sm">Cerrar Sesión Activa</h4>
                <p className="text-[10px] text-slate-450 uppercase font-mono tracking-wide">Mafort Hub & Control de Calidad</p>
              </div>
            </div>

            <p className="text-xs text-slate-600 leading-relaxed font-sans">
              ¿Seguro que desea salir del sistema? Se registrará la bitácora de desconexión técnica. Todo cambio guardado offline permanecerá a salvo en este dispositivo.
            </p>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setShowLogoutConfirm(false)}
                className="bg-slate-100 hover:bg-slate-200 text-slate-700 border border-slate-200 px-3.5 py-2 rounded-xl text-xs font-semibold cursor-pointer transition-all"
                id="cancel-logout-btn"
              >
                Cancelar
              </button>
              <button
                type="button"
                onClick={() => {
                  setShowLogoutConfirm(false);
                  const newAuditLog: UserActivityLog = {
                    id: `log_${Date.now()}`,
                    timestamp: new Date().toISOString().replace('T', ' ').substring(0, 19),
                    userEmail: currentUser?.email || 'sistema',
                    action: 'INICIO_SESION',
                    details: 'Cierre de sesión seguro realizado exitosamente.',
                    ipAddress: '192.168.10.15'
                  };
                  handleAddLog(newAuditLog);
                  setCurrentUser(null);
                }}
                className="bg-rose-500 hover:bg-rose-600 text-white px-4 py-2 rounded-xl text-xs font-bold shadow-sm cursor-pointer transition-all animate-none"
                id="confirm-logout-btn"
              >
                Cerrar Sesión
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

const getAreaOperativa = (role: string) => {
  switch(role) {
    case 'Administrador': return 'Administración General';
    case 'Ventas': return 'Coordinación de Ventas';
    case 'Tecnico': return 'Mantenimiento Técnico';
    case 'Supervisor': return 'Supervisión de Campo';
    case 'Cliente': return 'Operaciones Sede Cliente';
    default: return 'Sistemas Corporativos';
  }
};
