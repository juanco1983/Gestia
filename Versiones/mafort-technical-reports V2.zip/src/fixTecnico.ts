import * as fs from 'fs';

const filePath = './src/components/TecnicoView.tsx';
let content = fs.readFileSync(filePath, 'utf8');

content = content.replace(/OTStatus\.PENDIENTE/g, 'OTStatus.PROGRAMADA');
content = content.replace(/OTStatus\.EN_PROCESO/g, 'OTStatus.TRABAJO_EN_EJECUCION');
content = content.replace(/OTStatus\.REVISION/g, 'OTStatus.EN_REVISION');
content = content.replace(/OTStatus\.CORRECCION/g, 'OTStatus.OBSERVADA');
content = content.replace(/OTStatus\.APROBADO/g, 'OTStatus.APROBADA');
content = content.replace(/OTStatus\.FIRMADO/g, 'OTStatus.FIRMADA');

fs.writeFileSync(filePath, content, 'utf8');
console.log('Updated TecnicoView.tsx');
