import { OrdenTrabajoLinea, Contrato, TargetVentas } from '../types';

export const INITIAL_TARGET_VENTAS: TargetVentas[] = [
  { id: 't_1', anio: 2026, mes_num: 1, mes: 'ENE', target_ventas_usd: 35000 },
  { id: 't_2', anio: 2026, mes_num: 2, mes: 'FEB', target_ventas_usd: 40000 },
  { id: 't_3', anio: 2026, mes_num: 3, mes: 'MAR', target_ventas_usd: 45000 },
  { id: 't_4', anio: 2026, mes_num: 4, mes: 'ABR', target_ventas_usd: 40000 },
  { id: 't_5', anio: 2026, mes_num: 5, mes: 'MAY', target_ventas_usd: 50000 },
  { id: 't_6', anio: 2026, mes_num: 6, mes: 'JUN', target_ventas_usd: 55000 },
  { id: 't_7', anio: 2026, mes_num: 7, mes: 'JUL', target_ventas_usd: 60000 },
  { id: 't_8', anio: 2026, mes_num: 8, mes: 'AGO', target_ventas_usd: 50000 },
  { id: 't_9', anio: 2026, mes_num: 9, mes: 'SET', target_ventas_usd: 45000 },
  { id: 't_10', anio: 2026, mes_num: 10, mes: 'OCT', target_ventas_usd: 50000 },
  { id: 't_11', anio: 2026, mes_num: 11, mes: 'NOV', target_ventas_usd: 55000 },
  { id: 't_12', anio: 2026, mes_num: 12, mes: 'DIC', target_ventas_usd: 65000 }
];

export const INITIAL_CONTRATOS_NUEVOS: Contrato[] = [
  {
    id: 'cont_250',
    cliente: 'Banco de Crédito del Perú',
    ot_marco: 250,
    tipo_servicio: 'CONTRATO',
    tipo_contract: 'Climatización de Precisión 50HP',
    fecha_inicio: '2026-02-15',
    fecha_fin: '2027-02-14',
    estado: 'VIGENTE',
    comercial: 'Juan Córdova',
    comentarios: 'Mantenimiento programado',
    clientId: 'client_2',
    comercialId: 'user_5'
  } as any,
  {
    id: 'cont_251',
    cliente: 'Clínica Internacional',
    ot_marco: 251,
    tipo_servicio: 'CONTRATO',
    tipo_contract: 'Mantenimiento Preventivo y Emergencia UPS 30KVA',
    fecha_inicio: '2026-01-01',
    fecha_fin: '2026-12-31',
    estado: 'VIGENTE',
    comercial: 'Juan Córdova',
    comentarios: 'Atención inmediata',
    clientId: 'client_1',
    comercialId: 'user_5'
  } as any
];

export const INITIAL_ORDENES_TRABAJO: OrdenTrabajoLinea[] = [
  {
    id: 'otl_1',
    anio: 2026,
    ot_marco: 250,
    ot: '250-1',
    mes: 'JUN',
    fecha: '2026-06-30',
    nombre_solicitante: 'Juan Córdova',
    razon_social: 'Banco de Crédito del Perú',
    empresa: 'BCP',
    descripcion: 'Servicio de Mantenimiento Preventivo del Sistema de Climatización',
    n_cotizacion: 'COT-2026-102',
    n_oc_os: 'OC-4051',
    simbolo_moneda: '$',
    monto_marco_sin_igv: 5000,
    monto_marco_inc_igv: 5900,
    sub_importe_sin_igv: 5000,
    sub_importe_inc_igv: 5900,
    total_usd: 5000,
    anio_prog_facturacion: 2026,
    mes_prog_servicio: 'JUN',
    mes_prog_facturacion: 'SET',
    tipo_venta: 'MANTENIMIENTO',
    pendiente: 'POR EJECUTAR',
    estado: 'POR FACTURAR',
    n_factura: '',
    nro_guia_informe: '',
    observacion: 'Mantenimiento programado para fines de Junio',
    seguimiento: 'Coordinado con el cliente.',
    tipo_contratacion: 'CONTRATO',
    estatus: [],
    comercial: 'Juan Córdova',
    creadoPor: 'admin@mafort.pe',
    creadoEn: '2026-06-26',
    clientId: 'client_2',
    comercialId: 'user_5'
  },
  {
    id: 'otl_2',
    anio: 2026,
    ot_marco: 251,
    ot: '251-1',
    mes: 'JUL',
    fecha: '2026-07-05',
    nombre_solicitante: 'Juan Córdova',
    razon_social: 'Clínica Internacional',
    empresa: 'CLINICA',
    descripcion: 'Atención de Emergencia de Sistema de Energía Ininterrumpida UPS',
    n_cotizacion: 'COT-2026-103',
    n_oc_os: 'OC-4052',
    simbolo_moneda: '$',
    monto_marco_sin_igv: 3000,
    monto_marco_inc_igv: 3540,
    sub_importe_sin_igv: 3000,
    sub_importe_inc_igv: 3540,
    total_usd: 3000,
    anio_prog_facturacion: 2026,
    mes_prog_servicio: 'JUL',
    mes_prog_facturacion: 'JUL',
    tipo_venta: 'REPARACION',
    pendiente: 'POR EJECUTAR',
    estado: 'POR FACTURAR',
    n_factura: '',
    nro_guia_informe: '',
    observacion: 'Emergencia de UPS con baterías en mal estado',
    seguimiento: 'Coordinado para inicio de Julio',
    tipo_contratacion: 'CONTRATO',
    estatus: [],
    comercial: 'Juan Córdova',
    creadoPor: 'admin@mafort.pe',
    creadoEn: '2026-06-26',
    clientId: 'client_1',
    comercialId: 'user_5'
  }
];

export const MESES_ESPANOL = ['ENE', 'FEB', 'MAR', 'ABR', 'MAY', 'JUN', 'JUL', 'AGO', 'SET', 'OCT', 'NOV', 'DIC'];

export const TIPO_VENTA_VALUES = [
  'ALQUILER',
  'MANTENIMIENTO',
  'SERVICIO',
  'SUMINISTRO',
  'EMERGENCIA',
  'INSTALACION',
  'REPARACION',
  'PROYECTO',
  'ANULADO'
];

export const PENDIENTE_VALUES = [
  'EJECUTADO',
  'POR EJECUTAR',
  'ANULADO'
];

export const ESTADO_VALUES = [
  'FACTURADO',
  'POR FACTURAR',
  'ANULADO'
];

export const TIPO_CONTRATACION_VALUES = [
  'CONTRATO',
  'OC',
  'OS',
  'CORREO'
];
