import * as fs from 'fs';

const filePath = './src/App.tsx';
let content = fs.readFileSync(filePath, 'utf8');

// Replace view identifiers
content = content.replace(/Monitoreo/g, 'Operaciones');
content = content.replace(/GestionOTs/g, 'Facturacion');
content = content.replace(/ClientesContratos/g, 'Comercial');
content = content.replace(/Usuarios/g, 'Administracion');

// Ventas was merged to Comercial
// We can just keep Ventas for now, or replace it. I'll replace 'Ventas' with 'VentasOld' so we can ignore it if needed, or better, remove it from the menu.
// Actually, let's manually replace the menu block.
