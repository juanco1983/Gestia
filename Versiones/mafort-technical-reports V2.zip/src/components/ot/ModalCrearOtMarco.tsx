import React, { useState } from 'react';
import { Plus, X } from 'lucide-react';
import { OrdenTrabajoLinea, Client } from '../../types';
import { MESES_ESPANOL, TIPO_VENTA_VALUES, TIPO_CONTRATACION_VALUES } from '../../utils/otDefaults';

interface ModalCrearOtMarcoProps {
  clients: Client[];
  lineas: OrdenTrabajoLinea[];
  currentUser: { email: string; username: string };
  tipoCambio: number;
  onAddLinea: (linea: OrdenTrabajoLinea) => void;
  onClose: () => void;
}

export default function ModalCrearOtMarco({
  clients,
  lineas,
  currentUser,
  tipoCambio,
  onAddLinea,
  onClose
}: ModalCrearOtMarcoProps) {
  const [marcoForm, setMarcoForm] = useState({
    anio: new Date().getFullYear(),
    ot_marco: '',
    mes: MESES_ESPANOL[new Date().getMonth()],
    fecha: new Date().toISOString().split('T')[0],
    nombre_solicitante: '',
    razon_social: '',
    empresa: '',
    descripcion: '',
    n_cotizacion: '',
    n_oc_os: 'NO TIENE',
    simbolo_moneda: '$' as '$' | 'S/',
    monto_marco_sin_igv: 0,
    monto_marco_inc_igv: 0,
    sub_importe_sin_igv: 0,
    sub_importe_inc_igv: 0,
    anio_prog_facturacion: new Date().getFullYear(),
    mes_prog_servicio: MESES_ESPANOL[new Date().getMonth()],
    mes_prog_facturacion: MESES_ESPANOL[new Date().getMonth()],
    tipo_venta: 'MANTENIMIENTO' as any,
    tipo_contratacion: 'CONTRATO' as any,
    comercial: '',
    observacion: '',
    seguimiento: ''
  });

  const cleanString = (val: string) => val.trim().toUpperCase();

  const handleCreateMarcoSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!marcoForm.ot_marco || !marcoForm.razon_social) return;

    const otMarcoNum = parseInt(marcoForm.ot_marco);
    
    // Check if OT Marco already exists (strict duplicate defense)
    const exists = lineas.some(l => l.ot_marco === otMarcoNum);
    if (exists) {
      alert(`La OT Marco #${otMarcoNum} ya existe en el sistema.`);
      return;
    }

    // Auto-generate line correlative -1
    const subSinIgv = Number(marcoForm.sub_importe_sin_igv) || 0;
    const subIncIgv = Number(marcoForm.sub_importe_inc_igv) || 0;
    const isSoles = marcoForm.simbolo_moneda === 'S/';
    const totalUsd = isSoles ? (subSinIgv / tipoCambio) : subSinIgv;

    const clientObj = clients.find(cl => cl.razonSocial === marcoForm.razon_social);

    const firstLine: OrdenTrabajoLinea = {
      id: `otl_${Date.now()}_1`,
      anio: Number(marcoForm.anio) || new Date().getFullYear(),
      ot_marco: otMarcoNum,
      ot: `${otMarcoNum}-1`,
      mes: cleanString(marcoForm.mes),
      fecha: marcoForm.fecha,
      nombre_solicitante: marcoForm.nombre_solicitante.trim(),
      razon_social: marcoForm.razon_social,
      clientId: clientObj ? clientObj.id : undefined,
      empresa: marcoForm.empresa.trim() || marcoForm.razon_social.split(' ')[0],
      descripcion: marcoForm.descripcion.trim(),
      n_cotizacion: marcoForm.n_cotizacion.trim(),
      n_oc_os: marcoForm.n_oc_os.trim() || 'NO TIENE',
      simbolo_moneda: marcoForm.simbolo_moneda,
      monto_marco_sin_igv: Number(marcoForm.monto_marco_sin_igv) || 0,
      monto_marco_inc_igv: Number(marcoForm.monto_marco_inc_igv) || 0,
      sub_importe_sin_igv: subSinIgv,
      sub_importe_inc_igv: subIncIgv,
      total_usd: Number(totalUsd.toFixed(2)),
      anio_prog_facturacion: Number(marcoForm.anio_prog_facturacion) || new Date().getFullYear(),
      mes_prog_servicio: cleanString(marcoForm.mes_prog_servicio),
      mes_prog_facturacion: cleanString(marcoForm.mes_prog_facturacion),
      tipo_venta: marcoForm.tipo_venta,
      pendiente: 'POR EJECUTAR',
      estado: 'POR FACTURAR',
      n_factura: '',
      nro_guia_informe: '',
      observacion: marcoForm.observacion.trim(),
      seguimiento: marcoForm.seguimiento.trim(),
      tipo_contratacion: marcoForm.tipo_contratacion,
      estatus: [
        {
          fecha: new Date().toISOString().split('T')[0],
          autor: currentUser.email,
          texto: `OT Marco #${otMarcoNum} e inicio de línea 1 registrado por ${currentUser.username}.`
        }
      ],
      comercial: marcoForm.comercial.trim(),
      creadoPor: currentUser.email,
      creadoEn: new Date().toISOString().split('T')[0]
    };

    onAddLinea(firstLine);
    onClose();
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/40 backdrop-blur-sm p-4 overflow-y-auto" id="ot-modal-crear-marco">
      <div className="bg-white rounded-[28px] shadow-2xl w-full max-w-xl overflow-hidden border border-slate-100 my-8">
        <div className="bg-slate-50 px-6 py-4 border-b border-slate-150 flex items-center justify-between">
          <h3 className="font-black text-slate-800 text-sm flex items-center gap-2">
            <Plus size={16} className="text-[#00B594]" />
            Registrar Nueva OT Marco (Acuerdo Padre)
          </h3>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-slate-600 text-lg cursor-pointer p-1 rounded-full hover:bg-slate-100 transition-all"
          >
            <X size={18} />
          </button>
        </div>
        
        <form onSubmit={handleCreateMarcoSubmit} className="p-6 space-y-4 max-h-[80vh] overflow-y-auto text-xs font-sans">
          
          {/* Bloque 1: Datos Generales */}
          <div className="space-y-3.5">
            <h4 className="text-[10px] font-black uppercase tracking-wide text-[#00B594] font-mono border-b border-slate-100 pb-1">1. Datos Generales del Contrato</h4>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Año de Creación</label>
                <input
                  type="number"
                  required
                  value={marcoForm.anio}
                  onChange={(e) => setMarcoForm({ ...marcoForm, anio: parseInt(e.target.value) || 2026 })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                />
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Nro OT Marco <span className="text-rose-500">*</span></label>
                <input
                  type="number"
                  required
                  placeholder="Ej: 1109"
                  value={marcoForm.ot_marco}
                  onChange={(e) => setMarcoForm({ ...marcoForm, ot_marco: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800 focus:ring-1 focus:ring-[#00B594] font-mono font-bold"
                />
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Mes de Creación</label>
                <select
                  value={marcoForm.mes}
                  onChange={(e) => setMarcoForm({ ...marcoForm, mes: e.target.value })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                >
                  {MESES_ESPANOL.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Cliente Legal <span className="text-rose-500">*</span></label>
                <select
                  required
                  value={marcoForm.razon_social}
                  onChange={(e) => {
                    const s = e.target.value;
                    const clientObj = clients.find(cl => cl.razonSocial === s);
                    setMarcoForm({
                      ...marcoForm,
                      razon_social: s,
                      empresa: clientObj ? clientObj.razonSocial.split(' ')[0].toUpperCase() : '',
                      nombre_solicitante: clientObj ? clientObj.contactoNombre : ''
                    });
                  }}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800 focus:outline-none focus:border-[#00B594] transition-all"
                >
                  <option value="">Seleccione Cliente...</option>
                  {clients.map(c => <option key={c.id} value={c.razonSocial}>{c.razonSocial}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Empresa (Nombre Corto)</label>
                <input
                  type="text"
                  placeholder="Ej: REPSOL"
                  value={marcoForm.empresa}
                  onChange={(e) => setMarcoForm({ ...marcoForm, empresa: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                />
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Nro Cotización</label>
                <input
                  type="text"
                  placeholder="COT-2026-001"
                  value={marcoForm.n_cotizacion}
                  onChange={(e) => setMarcoForm({ ...marcoForm, n_cotizacion: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                />
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Nro OC / OS</label>
                <input
                  type="text"
                  placeholder="OS-8841"
                  value={marcoForm.n_oc_os}
                  onChange={(e) => setMarcoForm({ ...marcoForm, n_oc_os: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                />
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Responsable Comercial</label>
                <input
                  type="text"
                  placeholder="Ej: Carlos Mendoza"
                  value={marcoForm.comercial}
                  onChange={(e) => setMarcoForm({ ...marcoForm, comercial: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                />
              </div>
            </div>

            <div>
              <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Descripción del Servicio <span className="text-rose-500">*</span></label>
              <textarea
                required
                placeholder="Escriba el alcance detallado del servicio..."
                rows={2}
                value={marcoForm.descripcion}
                onChange={(e) => setMarcoForm({ ...marcoForm, descripcion: e.target.value })}
                className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
              />
            </div>
          </div>

          {/* Bloque 2: Importe Marco y Moneda */}
          <div className="space-y-3.5 pt-2">
            <h4 className="text-[10px] font-black uppercase tracking-wide text-[#00B594] font-mono border-b border-slate-100 pb-1">2. Presupuesto General Acordado</h4>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Moneda</label>
                <select
                  value={marcoForm.simbolo_moneda}
                  onChange={(e) => setMarcoForm({ ...marcoForm, simbolo_moneda: e.target.value as any })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-slate-800 font-bold"
                >
                  <option value="$">Dólares ($)</option>
                  <option value="S/">Soles (S/)</option>
                </select>
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Monto Marco (Sin IGV)</label>
                <input
                  type="number"
                  placeholder="0.00"
                  value={marcoForm.monto_marco_sin_igv}
                  onChange={(e) => {
                    const sin = Number(e.target.value) || 0;
                    setMarcoForm({
                      ...marcoForm,
                      monto_marco_sin_igv: sin,
                      monto_marco_inc_igv: Number((sin * 1.18).toFixed(2))
                    });
                  }}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-400 block mb-1 font-mono">Monto Marco (Con IGV)</label>
                <input
                  type="number"
                  placeholder="0.00"
                  value={marcoForm.monto_marco_inc_igv}
                  onChange={(e) => setMarcoForm({ ...marcoForm, monto_marco_inc_igv: Number(e.target.value) || 0 })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-slate-800 font-mono"
                />
              </div>
            </div>
          </div>

          {/* Bloque 3: Datos de la Primera Línea / Cuota auto-generada */}
          <div className="space-y-3.5 pt-2 bg-slate-50/50 p-4 rounded-2xl border border-slate-150">
            <h4 className="text-[10px] font-black uppercase tracking-wide text-[#00B594] font-mono border-b border-[#00B594]/20 pb-1">
              3. Datos de Primera Cuota Auto-generada ({marcoForm.ot_marco ? `${marcoForm.ot_marco}-1` : 'X-1'})
            </h4>
            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1 font-mono">Sub Importe (Sin IGV)</label>
                <input
                  type="number"
                  required
                  placeholder="0.00"
                  value={marcoForm.sub_importe_sin_igv}
                  onChange={(e) => {
                    const sin = Number(e.target.value) || 0;
                    setMarcoForm({
                      ...marcoForm,
                      sub_importe_sin_igv: sin,
                      sub_importe_inc_igv: Number((sin * 1.18).toFixed(2))
                    });
                  }}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1 font-mono">Sub Importe (Con IGV)</label>
                <input
                  type="number"
                  placeholder="0.00"
                  value={marcoForm.sub_importe_inc_igv}
                  onChange={(e) => setMarcoForm({ ...marcoForm, sub_importe_inc_igv: Number(e.target.value) || 0 })}
                  className="w-full bg-slate-50 border border-slate-200 rounded-xl py-2 px-3 text-slate-800 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1 font-mono">Tipo Venta</label>
                <select
                  value={marcoForm.tipo_venta}
                  onChange={(e) => setMarcoForm({ ...marcoForm, tipo_venta: e.target.value as any })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                >
                  {TIPO_VENTA_VALUES.map(t => <option key={t} value={t}>{t}</option>)}
                </select>
              </div>
            </div>

            <div className="grid grid-cols-3 gap-4">
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1 font-mono">Año Prog Fact</label>
                <input
                  type="number"
                  value={marcoForm.anio_prog_facturacion}
                  onChange={(e) => setMarcoForm({ ...marcoForm, anio_prog_facturacion: parseInt(e.target.value) || 2026 })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800 font-mono"
                />
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1 font-mono">Mes Prog Servicio</label>
                <select
                  value={marcoForm.mes_prog_servicio}
                  onChange={(e) => setMarcoForm({ ...marcoForm, mes_prog_servicio: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                >
                  {MESES_ESPANOL.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
              <div>
                <label className="text-[10px] font-extrabold uppercase text-slate-500 block mb-1 font-mono">Mes Prog Fact</label>
                <select
                  value={marcoForm.mes_prog_facturacion}
                  onChange={(e) => setMarcoForm({ ...marcoForm, mes_prog_facturacion: e.target.value })}
                  className="w-full bg-white border border-slate-200 rounded-xl py-2 px-3 text-slate-800"
                >
                  {MESES_ESPANOL.map(m => <option key={m} value={m}>{m}</option>)}
                </select>
              </div>
            </div>
          </div>

          {/* Botonera */}
          <div className="flex justify-end gap-2.5 pt-4 border-t border-slate-150">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 bg-slate-100 hover:bg-slate-200 text-slate-700 font-bold rounded-xl text-xs cursor-pointer transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="px-5 py-2.5 bg-[#00B594] hover:bg-[#009b7e] text-white font-black rounded-xl text-xs cursor-pointer shadow-lg transition-all"
            >
              Registrar Marco e Iniciar Línea
            </button>
          </div>

        </form>
      </div>
    </div>
  );
}
