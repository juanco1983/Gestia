import React, { useState } from 'react';
import { 
  Users, 
  Clock, 
  MapPin, 
  Wrench, 
  CheckCircle, 
  AlertCircle, 
  Search, 
  TrendingUp, 
  Calendar,
  Activity,
  User,
  ExternalLink,
  ChevronRight,
  ShieldAlert
} from 'lucide-react';
import { OT, OTStatus, Client, TechnicalReport } from '../types';

interface TechMonitoringDashboardProps {
  ots: OT[];
  clients: Client[];
  reports: TechnicalReport[];
  onUpdateOtStatus?: (otId: string, status: OTStatus) => void;
  onUpdateOt?: (ot: OT) => void;
}

export default function TechMonitoringDashboard({
  ots,
  clients,
  reports,
  onUpdateOtStatus,
  onUpdateOt
}: TechMonitoringDashboardProps) {
  const [filterTech, setFilterTech] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState<string>('');
  const [selectedTech, setSelectedTech] = useState<string | null>(null);
  
  // Assignment Modal State
  const [showAssignModal, setShowAssignModal] = useState(false);
  const [selectedOtToAssign, setSelectedOtToAssign] = useState<OT | null>(null);
  const [assignTitular, setAssignTitular] = useState<string>('');
  const [assignApoyo, setAssignApoyo] = useState<string>('');
  const [assignFecha, setAssignFecha] = useState<string>('');
  const [assignHora, setAssignHora] = useState<string>('');

  // List of all known technicians in the system
  const techniciansList = [
    { name: 'Carlos Ocsa', area: 'Sistemas de Potencia & UPS', avatar: 'CO', phone: '998194696' },
    { name: 'Gino Murillo', area: 'Climatización & Control', avatar: 'GM', phone: '999993709' },
    { name: 'Juan Córdova', area: 'Seguridad Eléctrica & Supervisor', avatar: 'JC', phone: '994512903' },
    { name: 'Josué Ale', area: 'Auxiliar Técnico Mecatrónico', avatar: 'JA', phone: '998412854' }
  ];

  const normalizeName = (name?: string) => {
    if (!name) return "";
    return name
      .toLowerCase()
      .normalize("NFD")
      .replace(/[\u0300-\u036f]/g, "")
      .trim();
  };

  const matchNames = (n1?: string, n2?: string) => {
    return normalizeName(n1) === normalizeName(n2);
  };

  // Map of active state details based on current OTs
  const getTechStatusAndDetails = (techName: string) => {
    // 1. Check if they are in an in-progress OT (visit in progress)
    const inProgressOt = ots.find(o => 
      (matchNames(o.tecnicoTitular, techName) || matchNames(o.tecnicoApoyo, techName)) && 
      o.estado === OTStatus.TRABAJO_EN_EJECUCION
    );

    if (inProgressOt) {
      const client = clients.find(c => c.id === inProgressOt.clientId);
      const report = reports.find(r => r.otId === inProgressOt.id);
      
      // Calculate progress of current field report
      let progressPercent = 10; // Basic start
      let currentStep = 'Arribo a Sede';
      
      if (report) {
        progressPercent = 30;
        currentStep = 'Mediciones de Entrada';
        if (report.diagnosticoGabinete?.cuentaConGabinete) {
          progressPercent = 50;
          currentStep = 'Diagnóstico Gabinete';
        }
        if (report.fotosLabeled && report.fotosLabeled.length > 0) {
          progressPercent = 75;
          currentStep = 'Evidencias Fotográficas';
        }
        if (report.firmaCliente) {
          progressPercent = 95;
          currentStep = 'Conformidad de Cliente';
        }
      }

      return {
        state: 'active' as const,
        statusText: 'En Visita Activa',
        badgeColor: 'bg-emerald-50 text-emerald-700 border-emerald-200',
        dotColor: 'bg-emerald-500',
        ot: inProgressOt,
        clientName: client?.razonSocial || 'Cliente General',
        location: `${client?.direccionSede || 'Sede'}, ${client?.distrito || 'Surco'}`,
        progressPercent,
        currentStep,
        equipment: `${inProgressOt.tipoEquipo} (${inProgressOt.potenciaKva} KVA)`
      };
    }

    // 2. Check if they have an upcoming pending OT
    const pendingOt = ots.find(o => 
      (matchNames(o.tecnicoTitular, techName) || matchNames(o.tecnicoApoyo, techName)) && 
      o.estado === OTStatus.PROGRAMADA
    );

    if (pendingOt) {
      const client = clients.find(c => c.id === pendingOt.clientId);
      return {
        state: 'pending' as const,
        statusText: 'Asignado (Espera/Traslado)',
        badgeColor: 'bg-amber-50 text-amber-700 border-amber-200',
        dotColor: 'bg-amber-500',
        ot: pendingOt,
        clientName: client?.razonSocial || 'Cliente General',
        location: `${client?.direccionSede || 'Sede'}, ${client?.distrito || 'Surco'}`,
        progressPercent: 0,
        currentStep: 'Listo para iniciar traslado',
        equipment: `${pendingOt.tipoEquipo} (${pendingOt.potenciaKva} KVA)`
      };
    }

    // 3. Under review or correcting reports
    const reviewOt = ots.find(o => 
      (matchNames(o.tecnicoTitular, techName) || matchNames(o.tecnicoApoyo, techName)) && 
      (o.estado === OTStatus.EN_REVISION || o.estado === OTStatus.OBSERVADA)
    );

    if (reviewOt) {
      const client = clients.find(c => c.id === reviewOt.clientId);
      return {
        state: 'review' as const,
        statusText: reviewOt.estado === OTStatus.OBSERVADA ? 'Atendiendo Correcciones' : 'Sometido a Revisión',
        badgeColor: reviewOt.estado === OTStatus.OBSERVADA ? 'bg-rose-50 text-rose-700 border-rose-200 animate-pulse' : 'bg-indigo-50 text-indigo-700 border-indigo-200',
        dotColor: reviewOt.estado === OTStatus.OBSERVADA ? 'bg-rose-500' : 'bg-indigo-500',
        ot: reviewOt,
        clientName: client?.razonSocial || 'Cliente General',
        location: `${client?.direccionSede || 'Sede'}, ${client?.distrito || 'Surco'}`,
        progressPercent: 100,
        currentStep: reviewOt.estado === OTStatus.OBSERVADA ? 'Subiendo corrección' : 'Esperando aprobación SLA',
        equipment: `${reviewOt.tipoEquipo} (${reviewOt.potenciaKva} KVA)`
      };
    }

    // 4. Free and available
    return {
      state: 'available' as const,
      statusText: 'Disponible / Guardia',
      badgeColor: 'bg-slate-100 text-slate-600 border-slate-200',
      dotColor: 'bg-slate-400',
      ot: null,
      clientName: 'N/A',
      location: 'Base de Operaciones Surco',
      progressPercent: 0,
      currentStep: 'A la espera de despacho de OT',
      equipment: 'N/A'
    };
  };

  // Compute stats for field status
  const activeVisitsCount = techniciansList.filter(t => getTechStatusAndDetails(t.name).state === 'active').length;
  const idleCount = techniciansList.filter(t => getTechStatusAndDetails(t.name).state === 'available').length;
  const transitCount = techniciansList.filter(t => getTechStatusAndDetails(t.name).state === 'pending').length;
  const underCorrectionCount = techniciansList.filter(t => getTechStatusAndDetails(t.name).state === 'review' && getTechStatusAndDetails(t.name).ot?.estado === OTStatus.OBSERVADA).length;

  // Unassigned OTs
  const unassignedOts = ots.filter(ot => ot.estado === OTStatus.PENDIENTE_PROGRAMACION || ot.estado === OTStatus.CREADA);

  // Filtered daily schedule list
  const filteredOts = ots.filter(ot => {
    if (ot.estado === OTStatus.PENDIENTE_PROGRAMACION || ot.estado === OTStatus.CREADA) return false; // Show only assigned/in progress here
    const client = clients.find(c => c.id === ot.clientId);
    const textMatch = (client?.razonSocial || '').toLowerCase().includes(searchQuery.toLowerCase()) || 
                      ot.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                      (ot.tecnicoTitular || '').toLowerCase().includes(searchQuery.toLowerCase());
    
    if (filterTech === 'all') return textMatch;
    return textMatch && (matchNames(ot.tecnicoTitular, filterTech) || matchNames(ot.tecnicoApoyo, filterTech));
  });

  const handleOpenAssignModal = (ot: OT) => {
    setSelectedOtToAssign(ot);
    setAssignTitular(ot.tecnicoTitular || techniciansList[0].name);
    setAssignApoyo(ot.tecnicoApoyo || '');
    setAssignFecha(ot.fechaProgramada || new Date().toISOString().split('T')[0]);
    setAssignHora(ot.horaProgramada || '09:00');
    setShowAssignModal(true);
  };

  const submitAssignment = () => {
    if (selectedOtToAssign && onUpdateOt) {
      onUpdateOt({
        ...selectedOtToAssign,
        tecnicoTitular: assignTitular,
        tecnicoApoyo: assignApoyo || undefined,
        fechaProgramada: assignFecha,
        horaProgramada: assignHora,
        estado: OTStatus.PROGRAMADA
      });
      setShowAssignModal(false);
      setSelectedOtToAssign(null);
    }
  };

  // Today's date representation formatted nicely in Spanish
  const todayStr = 'Martes 23 de Junio de 2026';

  return (
    <div className="space-y-6 font-sans text-slate-800 text-left" id="tech-monitoring-dashboard">
      {/* 1. REAL-TIME FIELD METRIC COUNTERS */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
        
        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider block">Visitas Activas</span>
            <div className="flex items-center gap-2 mt-1">
              <span className="relative flex h-3 w-3">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-3 w-3 bg-emerald-500"></span>
              </span>
              <h4 className="text-2xl font-bold text-slate-900 leading-none">{activeVisitsCount} <span className="text-xs text-slate-400 font-medium">técnicos</span></h4>
            </div>
            <p className="text-[10px] text-slate-500 mt-1">Enlace ODS satelital activo</p>
          </div>
          <div className="bg-emerald-50 text-emerald-600 p-2.5 rounded-lg"><Activity size={20} className="animate-pulse" /></div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider block">En Traslado / Tránsito</span>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="w-2.5 h-2.5 rounded-full bg-amber-500"></span>
              <h4 className="text-2xl font-bold text-slate-900 leading-none">{transitCount} <span className="text-xs text-slate-400 font-medium font-sans">ruta</span></h4>
            </div>
            <p className="text-[10px] text-slate-500 mt-1">Próximo inicio de mediciones</p>
          </div>
          <div className="bg-amber-50 text-amber-600 p-2.5 rounded-lg"><Clock size={20} /></div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider block">Técnicos Disponibles</span>
            <div className="flex items-center gap-1.5 mt-1">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-400"></span>
              <h4 className="text-2xl font-bold text-slate-900 leading-none">{idleCount} <span className="text-xs text-slate-400 font-medium font-sans">en base</span></h4>
            </div>
            <p className="text-[10px] text-slate-500 mt-1">Soporte y emergencias 24/7</p>
          </div>
          <div className="bg-slate-100 text-slate-600 p-2.5 rounded-lg"><Users size={20} /></div>
        </div>

        <div className="bg-white p-4 rounded-xl border border-slate-200 shadow-sm flex items-center justify-between">
          <div>
            <span className="text-[10px] uppercase font-bold text-slate-400 font-mono tracking-wider block">Correcciones Urgentes</span>
            <div className="flex items-center gap-1.5 mt-1">
              <span className={`w-2.5 h-2.5 rounded-full ${underCorrectionCount > 0 ? 'bg-rose-500 animate-ping' : 'bg-slate-400'}`}></span>
              <h4 className="text-2xl font-bold text-slate-900 leading-none">{underCorrectionCount} <span className="text-xs text-slate-400 font-medium font-sans">rechazo</span></h4>
            </div>
            <p className="text-[10px] text-slate-500 mt-1">SLA requiere enmienda</p>
          </div>
          <div className="bg-rose-50 text-rose-600 p-2.5 rounded-lg"><ShieldAlert size={20} /></div>
        </div>

      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        
        {/* 2. REAL-TIME TECHNICIANS FIELD GRID (2 Cols) */}
        <div className="lg:col-span-2 space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs">
            <div className="flex items-center justify-between border-b border-slate-100 pb-3.5">
              <div>
                <h3 className="text-sm font-bold text-slate-900 uppercase font-mono tracking-tight flex items-center gap-2">
                  <Users size={16} className="text-emerald-500" />
                  <span>Estado de Técnicos de Campo en Tiempo Real</span>
                </h3>
                <p className="text-xs text-slate-400 mt-0.5">Control de cuadrilla y avance de llenado de fichas de servicio fáctico</p>
              </div>
              <span className="text-[10px] bg-emerald-50 text-emerald-700 px-2 py-0.5 rounded font-mono font-bold">GPS Activo</span>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-4">
              {techniciansList.map((tech) => {
                const status = getTechStatusAndDetails(tech.name);
                const isSelected = selectedTech === tech.name;

                return (
                  <div 
                    key={tech.name} 
                    className={`p-4 rounded-xl border transition-all duration-200 flex flex-col justify-between gap-3 bg-white text-left ${
                      isSelected 
                        ? 'border-emerald-500 ring-2 ring-emerald-500/15 shadow-md bg-slate-50/50' 
                        : 'border-slate-200 hover:border-slate-350 hover:shadow-xs'
                    }`}
                  >
                    {/* Tech Profile & Status */}
                    <div className="flex items-start justify-between gap-2.5">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-full bg-slate-100 border border-slate-200 flex items-center justify-center font-bold text-slate-700 text-sm font-mono shrink-0 relative">
                          {tech.avatar}
                          <span className={`absolute bottom-0 right-0 w-2.5 h-2.5 rounded-full border-2 border-white ${status.dotColor}`}></span>
                        </div>
                        <div>
                          <h4 className="font-extrabold text-slate-900 text-sm leading-tight">{tech.name}</h4>
                          <span className="text-[10px] text-slate-400 font-mono tracking-tight font-medium block mt-0.5">{tech.area}</span>
                        </div>
                      </div>

                      <span className={`text-[9px] font-bold font-mono px-2 py-0.5 rounded-full border ${status.badgeColor}`}>
                        {status.statusText}
                      </span>
                    </div>

                    {/* Active Assignment Info */}
                    {status.ot ? (
                      <div className="bg-slate-50 p-2.5 rounded-lg border border-slate-100 text-xs space-y-2">
                        <div className="flex justify-between items-center text-[10px]">
                          <span className="font-mono text-emerald-600 font-bold">{status.ot.id}</span>
                          <span className="text-slate-400 font-medium">{status.equipment}</span>
                        </div>
                        <div className="space-y-0.5">
                          <span className="text-slate-400 font-bold block text-[10px] uppercase font-mono">CLIENTE:</span>
                          <span className="font-bold text-slate-800 leading-snug block truncate">{status.clientName}</span>
                        </div>
                        <div className="flex items-center gap-1 text-slate-500 text-[10px]">
                          <MapPin size={11} className="shrink-0 text-slate-400" />
                          <span className="truncate">{status.location}</span>
                        </div>

                        {/* Progress Bar of Report filling */}
                        <div className="space-y-1 pt-1 border-t border-slate-200/50">
                          <div className="flex justify-between items-center text-[9px] font-mono">
                            <span className="text-slate-500 font-semibold">{status.currentStep}</span>
                            <span className="text-emerald-600 font-black">{status.progressPercent}%</span>
                          </div>
                          <div className="w-full bg-slate-200 h-1 rounded-full overflow-hidden">
                            <div className="bg-emerald-500 h-full rounded-full transition-all duration-300" style={{ width: `${status.progressPercent}%` }}></div>
                          </div>
                        </div>
                      </div>
                    ) : (
                      <div className="bg-slate-50/50 p-3 rounded-lg border border-dashed border-slate-200 text-center py-5">
                        <span className="text-[10px] text-slate-400 font-mono italic">Disponible para re-despacho de OTs urgentes</span>
                      </div>
                    )}

                    {/* Simulation trigger buttons */}
                    <div className="flex items-center gap-1.5 justify-between pt-1 border-t border-slate-100/50 text-xs">
                      <span className="text-[9px] font-mono text-slate-450">Telf: {tech.phone}</span>
                      <div className="flex items-center gap-1.5">
                        {status.ot && onUpdateOtStatus && (
                          <button
                            onClick={() => {
                              if (status.ot?.estado === OTStatus.TRABAJO_EN_EJECUCION) {
                                onUpdateOtStatus(status.ot.id, OTStatus.EN_REVISION);
                                alert(`🔄 Simulación: Técnico ${tech.name} ha terminado el servicio de campo y enviado el informe ${status.ot.id} a revisión.`);
                              } else if (status.ot?.estado === OTStatus.PROGRAMADA) {
                                onUpdateOtStatus(status.ot.id, OTStatus.TRABAJO_EN_EJECUCION);
                                alert(`🔄 Simulación: Técnico ${tech.name} ha arribado a sede de cliente e iniciado el servicio de campo para ${status.ot.id}.`);
                              }
                            }}
                            className="text-[10px] bg-slate-900 text-white hover:bg-slate-850 p-1 px-2.5 rounded font-bold font-mono transition-colors cursor-pointer"
                          >
                            {status.ot.estado === OTStatus.PROGRAMADA ? 'Simular Iniciar Visita' : 'Simular Enviar Reporte'}
                          </button>
                        )}
                        <button
                          onClick={() => setSelectedTech(selectedTech === tech.name ? null : tech.name)}
                          className="text-[10px] text-indigo-600 hover:text-indigo-800 font-bold transition-colors underline cursor-pointer font-mono"
                        >
                          {isSelected ? 'Cerrar' : 'Detalle'}
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        </div>

        {/* 3. TODAY'S DAILY TIMELINE & PROGRAMMING (1 Col) */}
        <div className="space-y-4">
          <div className="bg-white p-5 rounded-2xl border border-slate-200 shadow-xs flex flex-col justify-between min-h-full">
            <div className="space-y-3">
              <div className="flex items-center justify-between border-b border-slate-100 pb-3">
                <h3 className="text-sm font-bold text-slate-900 uppercase font-mono tracking-tight flex items-center gap-2">
                  <Calendar size={16} className="text-amber-500 animate-pulse" />
                  <span>Programación del Día</span>
                </h3>
                <span className="text-[9px] bg-amber-500/10 text-amber-700 px-2 py-0.5 rounded font-mono font-bold leading-none">Hoy</span>
              </div>

              {/* Date banner */}
              <div className="bg-slate-50 border border-slate-150 rounded-xl p-3 text-center space-y-1">
                <span className="text-[10px] text-slate-400 font-mono uppercase block font-semibold">Fecha Programación Activa</span>
                <span className="text-xs font-black text-slate-800 font-sans block">{todayStr}</span>
              </div>

              {/* Filters / Search within Timeline */}
              <div className="space-y-2">
                <div className="relative">
                  <Search className="absolute left-2.5 top-2 text-slate-400" size={13} />
                  <input
                    type="text"
                    placeholder="Filtrar por cliente, OT o técnico..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg pl-8 pr-3 py-1 text-xs focus:outline-none focus:border-amber-500 font-sans"
                  />
                </div>

                <div className="flex gap-1 overflow-x-auto pb-1 text-[10px] font-mono">
                  <button 
                    onClick={() => setFilterTech('all')} 
                    className={`px-2 py-1 rounded transition-colors shrink-0 cursor-pointer ${filterTech === 'all' ? 'bg-slate-900 text-white font-bold' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                  >
                    Todos
                  </button>
                  {techniciansList.map(t => (
                    <button 
                      key={t.name}
                      onClick={() => setFilterTech(t.name)} 
                      className={`px-2 py-1 rounded transition-colors shrink-0 cursor-pointer ${filterTech === t.name ? 'bg-amber-500 text-slate-950 font-bold' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
                    >
                      {t.name.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>

              {/* Timeline Cards */}
              <div className="space-y-3 pt-2 max-h-[350px] overflow-y-auto pr-1">
                {/* Unassigned OTs Block */}
                {unassignedOts.length > 0 && (
                  <div className="mb-4">
                    <div className="flex items-center gap-2 mb-2">
                      <span className="text-[10px] uppercase font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">Órdenes por Asignar ({unassignedOts.length})</span>
                    </div>
                    <div className="space-y-2">
                      {unassignedOts.map((ot) => {
                        const client = clients.find(c => c.id === ot.clientId);
                        return (
                          <div key={ot.id} className="relative pl-5 border-l border-slate-200/80 last:border-0 pb-1 text-left">
                            <span className="absolute left-[-5px] top-1.5 w-2.5 h-2.5 rounded-full ring-4 ring-white bg-slate-200 border-2 border-slate-300"></span>
                            
                            <div className="bg-slate-50 hover:bg-slate-100/60 transition-all border border-slate-200/80 rounded-xl p-3 space-y-1.5 relative group shadow-sm">
                              <div className="flex justify-between items-center gap-2">
                                <span className="font-mono text-[11px] font-black text-amber-500">{ot.id}</span>
                                <span className="text-[8.5px] font-bold font-mono px-1.5 py-0.2 rounded-full border leading-none bg-slate-200 text-slate-800 border-slate-300">
                                  {ot.estado}
                                </span>
                              </div>
                              <div className="space-y-0.5">
                                <span className="text-slate-400 font-extrabold block text-[9px] uppercase font-mono">CLIENTE:</span>
                                <span className="font-bold text-slate-800 text-[11px] leading-tight block truncate" title={client?.razonSocial}>
                                  {client?.razonSocial || 'Cliente General'}
                                </span>
                              </div>
                              <div className="bg-white/80 border border-slate-100 text-[9.5px] px-2 py-0.5 rounded font-mono text-slate-450 flex justify-between items-center mt-1">
                                <span>{ot.tipoEquipo} • {ot.potenciaKva}KVA</span>
                                <span>{ot.fechaProgramada} {ot.horaProgramada ? `• ${ot.horaProgramada}` : ''}</span>
                              </div>
                              <div className="pt-2">
                                <button
                                  onClick={() => handleOpenAssignModal(ot)}
                                  className="w-full bg-slate-900 text-white text-[10px] font-bold py-1.5 rounded-lg hover:bg-slate-800 transition-colors"
                                >
                                  Asignar Técnico
                                </button>
                              </div>
                            </div>
                          </div>
                        );
                      })}
                    </div>
                  </div>
                )}

                {/* Assigned/In Progress OTs */}
                <div className="flex items-center gap-2 mb-2">
                  <span className="text-[10px] uppercase font-mono font-bold text-slate-500 bg-slate-100 px-2 py-0.5 rounded">Órdenes Asignadas / En Curso</span>
                </div>
                {filteredOts.length === 0 ? (
                  <div className="p-8 text-center text-slate-400 text-xs font-mono border border-dashed border-slate-200 rounded-xl">
                    No hay órdenes programadas que coincidan con la búsqueda.
                  </div>
                ) : (
                  filteredOts.map((ot) => {
                    const client = clients.find(c => c.id === ot.clientId);
                    return (
                      <div key={ot.id} className="relative pl-5 border-l border-slate-200/80 last:border-0 pb-1 text-left">
                        {/* Bullet indicators */}
                        <span className={`absolute left-[-5px] top-1.5 w-2.5 h-2.5 rounded-full ring-4 ring-white ${
                          ot.estado === OTStatus.PROGRAMADA ? 'bg-slate-400' :
                          ot.estado === OTStatus.TRABAJO_EN_EJECUCION ? 'bg-emerald-500 animate-ping' :
                          ot.estado === OTStatus.EN_REVISION ? 'bg-indigo-500' :
                          ot.estado === OTStatus.OBSERVADA ? 'bg-rose-500' :
                          'bg-sky-500'
                        }`}></span>

                        <div className="bg-slate-50 hover:bg-slate-100/60 transition-all border border-slate-200/80 rounded-xl p-3 space-y-1.5 relative group">
                          <div className="flex justify-between items-center gap-2">
                            <span className="font-mono text-[11px] font-black text-amber-500">{ot.id}</span>
                            <span className={`text-[8.5px] font-bold font-mono px-1.5 py-0.2 rounded-full border leading-none ${
                              ot.estado === OTStatus.PROGRAMADA ? 'bg-slate-100 text-slate-600 border-slate-200' :
                              ot.estado === OTStatus.TRABAJO_EN_EJECUCION ? 'bg-emerald-50 text-emerald-700 border-emerald-200' :
                              ot.estado === OTStatus.EN_REVISION ? 'bg-indigo-50 text-indigo-700 border-indigo-200' :
                              ot.estado === OTStatus.OBSERVADA ? 'bg-rose-50 text-rose-700 border-rose-200' :
                              'bg-sky-50 text-sky-700 border-sky-200'
                            }`}>
                              {ot.estado.split(' ')[0]}
                            </span>
                          </div>

                          <div className="space-y-0.5">
                            <span className="text-slate-400 font-extrabold block text-[9px] uppercase font-mono">CLIENTE:</span>
                            <span className="font-bold text-slate-800 text-[11px] leading-tight block truncate" title={client?.razonSocial}>
                              {client?.razonSocial || 'Cliente General'}
                            </span>
                          </div>

                          <div className="flex flex-wrap items-center justify-between gap-1 text-[10px] text-slate-500 font-mono">
                            <span>Ing: <strong className="text-slate-700 font-semibold">{ot.tecnicoTitular}</strong></span>
                            <span>{ot.tipoMantenimiento}</span>
                          </div>

                          <div className="bg-white/80 border border-slate-100 text-[9.5px] px-2 py-0.5 rounded font-mono text-slate-450 flex justify-between items-center mt-1">
                            <span>{ot.tipoEquipo} • {ot.potenciaKva}KVA</span>
                            <span>{ot.fechaProgramada} {ot.horaProgramada ? `• ${ot.horaProgramada}` : ''}</span>
                          </div>
                          
                          {ot.estado === OTStatus.PROGRAMADA && (
                            <div className="pt-2">
                              <button
                                onClick={() => handleOpenAssignModal(ot)}
                                className="w-full bg-slate-100 text-slate-600 text-[10px] font-bold py-1.5 rounded-lg hover:bg-slate-200 transition-colors border border-slate-300"
                              >
                                Reasignar Técnico
                              </button>
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })
                )}
              </div>
            </div>

            {/* SLA Compliance summary block */}
            <div className="bg-slate-900 text-slate-100 p-3.5 rounded-xl border border-slate-800 space-y-2 text-xs font-mono mt-4">
              <div className="flex justify-between items-center text-[10px] text-slate-400 uppercase tracking-wider">
                <span>Avance de OTs de Hoy</span>
                <span className="font-bold text-emerald-400">
                  {ots.filter(o => o.estado === OTStatus.FIRMADA || o.estado === OTStatus.APROBADA).length} de {ots.length} OK
                </span>
              </div>
              <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                <div 
                  className="bg-emerald-500 h-full rounded-full transition-all duration-500"
                  style={{ width: `${(ots.filter(o => o.estado === OTStatus.FIRMADA || o.estado === OTStatus.APROBADA).length / ots.length) * 100}%` }}
                ></div>
              </div>
              <p className="text-[9px] text-slate-400 leading-snug font-sans">
                💡 Los técnicos sincronizan las firmas de campo en tiempo real. Al cerrarse la firma del cliente, la OT ingresa al módulo de ventas de forma inmediata.
              </p>
            </div>
          </div>
        </div>

      </div>

      {/* Assignment Modal */}
      {showAssignModal && selectedOtToAssign && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-slate-900/50 backdrop-blur-sm">
          <div className="bg-white rounded-2xl shadow-xl w-full max-w-md overflow-hidden animate-in fade-in zoom-in-95 duration-200">
            <div className="flex items-center justify-between p-4 border-b border-slate-100 bg-slate-50/50">
              <h3 className="font-bold text-slate-800 text-sm flex items-center gap-2">
                <Users size={16} className="text-emerald-500" />
                Asignar Cuadrilla a OT
              </h3>
              <button onClick={() => setShowAssignModal(false)} className="text-slate-400 hover:text-slate-700">
                &times;
              </button>
            </div>
            
            <div className="p-5 space-y-4">
              <div className="bg-slate-50 p-3 rounded-lg border border-slate-100 text-xs">
                <span className="font-mono text-amber-600 font-bold block mb-1">{selectedOtToAssign.id}</span>
                <span className="text-slate-600 truncate block">
                  {clients.find(c => c.id === selectedOtToAssign.clientId)?.razonSocial || 'Cliente General'}
                </span>
                <span className="text-slate-500 mt-1 block">
                  {selectedOtToAssign.tipoEquipo} • {selectedOtToAssign.potenciaKva}KVA
                </span>
              </div>

              <div className="space-y-3">
                <div>
                  <label className="block text-[10px] uppercase font-mono text-slate-500 mb-1 font-bold">Técnico Titular (Requerido)</label>
                  <select 
                    value={assignTitular}
                    onChange={(e) => setAssignTitular(e.target.value)}
                    className="w-full text-sm border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-emerald-500 outline-none"
                  >
                    {techniciansList.map(t => (
                      <option key={t.name} value={t.name}>{t.name} - {t.area}</option>
                    ))}
                  </select>
                </div>
                
                <div>
                  <label className="block text-[10px] uppercase font-mono text-slate-500 mb-1 font-bold">Técnico de Apoyo (Opcional)</label>
                  <select 
                    value={assignApoyo}
                    onChange={(e) => setAssignApoyo(e.target.value)}
                    className="w-full text-sm border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-emerald-500 outline-none"
                  >
                    <option value="">-- Sin apoyo --</option>
                    {techniciansList.map(t => (
                      <option key={t.name} value={t.name} disabled={t.name === assignTitular}>{t.name} - {t.area}</option>
                    ))}
                  </select>
                </div>

                <div className="grid grid-cols-2 gap-3 border-t border-slate-100 pt-3">
                  <div>
                    <label className="block text-[10px] uppercase font-mono text-slate-500 mb-1 font-bold">Fecha Programada</label>
                    <input 
                      type="date"
                      required
                      value={assignFecha}
                      onChange={(e) => setAssignFecha(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-emerald-500 outline-none font-mono"
                    />
                  </div>
                  <div>
                    <label className="block text-[10px] uppercase font-mono text-slate-500 mb-1 font-bold">Hora Visita</label>
                    <input 
                      type="time"
                      required
                      value={assignHora}
                      onChange={(e) => setAssignHora(e.target.value)}
                      className="w-full text-xs border border-slate-200 rounded-lg p-2 focus:ring-1 focus:ring-emerald-500 outline-none font-mono"
                    />
                  </div>
                </div>
              </div>
            </div>

            <div className="p-4 bg-slate-50 border-t border-slate-100 flex justify-end gap-2">
              <button 
                onClick={() => setShowAssignModal(false)}
                className="px-4 py-2 text-xs font-bold text-slate-600 hover:text-slate-800 transition-colors"
              >
                Cancelar
              </button>
              <button 
                onClick={submitAssignment}
                className="px-4 py-2 bg-emerald-500 text-white text-xs font-bold rounded-lg hover:bg-emerald-600 transition-colors shadow-sm"
              >
                Confirmar Asignación
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
