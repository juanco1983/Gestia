import { Client, Contract, OT, ServiceType, EquipmentType, OTStatus, User, UserActivityLog } from './types';

export const INITIAL_USERS: User[] = [
  {
    id: 'user_0',
    username: 'Administrador General',
    email: 'admin@mafort.pe',
    role: 'Administrador',
    estado: 'Activo',
    area: 'Administración General',
    ultimoIngreso: '2026-06-22 07:00',
    creadoEn: '2026-01-01',
    allowedModules: ['Dashboard', 'Monitoreo', 'GestionOTs', 'ClientesContratos', 'Ventas', 'Tecnico', 'Supervisor', 'Cliente', 'Usuarios']
  },
  {
    id: 'user_1',
    username: 'Coord. Ventas',
    email: 'ventas@mafort.pe',
    role: 'Ventas',
    estado: 'Activo',
    area: 'Planeamiento Comercial',
    ultimoIngreso: '2026-06-22 07:15',
    creadoEn: '2026-01-10',
    allowedModules: ['Dashboard', 'Monitoreo', 'GestionOTs', 'ClientesContratos', 'Ventas']
  },
  {
    id: 'user_2',
    username: 'Carlos Ocsa',
    email: 'tecnico@mafort.pe',
    role: 'Tecnico',
    estado: 'Activo',
    area: 'Mantenimiento de Campo',
    ultimoIngreso: '2026-06-22 07:22',
    creadoEn: '2026-01-12',
    allowedModules: ['Dashboard', 'Monitoreo', 'Tecnico']
  },
  {
    id: 'user_3',
    username: 'Ing. Supervisor',
    email: 'supervisor@mafort.pe',
    role: 'Supervisor',
    estado: 'Activo',
    area: 'Control de Calidad (SLA)',
    ultimoIngreso: '2026-06-22 07:10',
    creadoEn: '2026-01-15',
    allowedModules: ['Dashboard', 'Monitoreo', 'Supervisor']
  },
  {
    id: 'user_4',
    username: 'Rep. Prosegur',
    email: 'cliente@mafort.pe',
    role: 'Cliente',
    estado: 'Activo',
    area: 'Seguridad y Operaciones',
    ultimoIngreso: '2026-06-22 06:45',
    creadoEn: '2026-02-01',
    allowedModules: ['Dashboard', 'Monitoreo', 'Cliente']
  },
  {
    id: 'user_5',
    username: 'Juan Córdova',
    email: 'juan.cordova@materiagris.pe',
    role: 'Tecnico',
    estado: 'Activo',
    area: 'Seguridad Eléctrica & Supervisor',
    ultimoIngreso: '2026-06-24 15:10',
    creadoEn: '2026-01-20',
    allowedModules: ['Dashboard', 'Monitoreo', 'Tecnico']
  }
];

export const INITIAL_LOGS: UserActivityLog[] = [
  {
    id: 'log_1',
    timestamp: '2026-06-22 06:45:12',
    userEmail: 'cliente@mafort.pe',
    action: 'INICIO_SESION',
    details: 'Autenticación exitosa mediante acceso rápido',
    ipAddress: '192.168.10.45'
  },
  {
    id: 'log_2',
    timestamp: '2026-06-22 07:10:04',
    userEmail: 'supervisor@mafort.pe',
    action: 'INICIO_SESION',
    details: 'Autenticación exitosa IP certificada',
    ipAddress: '192.168.10.12'
  },
  {
    id: 'log_3',
    timestamp: '2026-06-22 07:15:22',
    userEmail: 'ventas@mafort.pe',
    action: 'INICIO_SESION',
    details: 'Inicio de jornada operacional comercial',
    ipAddress: '192.168.10.20'
  },
  {
    id: 'log_4',
    timestamp: '2026-06-22 07:22:15',
    userEmail: 'tecnico@mafort.pe',
    action: 'INICIO_SESION',
    details: 'Acceso móvil de personal técnico titular',
    ipAddress: '192.168.10.35'
  }
];


export const INITIAL_CLIENTS: Client[] = [
  {
    id: 'client_1',
    razonSocial: 'Clínica Internacional',
    ruc: '20100112233',
    direccionSede: 'Av. Garcilaso de la Vega 1420',
    distrito: 'Cercado de Lima',
    contactoNombre: 'Juan Córdova',
    contactoEmail: 'juan.cordova@materiagris.pe',
    contactoTelefono: '994512903'
  },
  {
    id: 'client_2',
    razonSocial: 'Banco de Crédito del Perú',
    ruc: '20100047218',
    direccionSede: 'Calle Centenario 156',
    distrito: 'La Molina',
    contactoNombre: 'Ing. Soporte BCP',
    contactoEmail: 'bcp_soporte@bcp.com.pe',
    contactoTelefono: '987654321'
  }
];

export const INITIAL_CONTRACTS: Contract[] = [
  {
    id: 'contra_1',
    clientId: 'client_1',
    tipoEquipo: EquipmentType.UPS,
    visitasAnuales: 4,
    fechaInicio: '2026-01-01',
    fechaFin: '2026-12-31'
  },
  {
    id: 'contra_2',
    clientId: 'client_2',
    tipoEquipo: EquipmentType.CLIMATIZACION,
    visitasAnuales: 6,
    fechaInicio: '2026-02-15',
    fechaFin: '2027-02-14'
  }
];

export const INITIAL_OTS: OT[] = [
  {
    id: 'OT-250',
    clientId: 'client_2',
    tipoMantenimiento: ServiceType.PREVENTIVO,
    tipoEquipo: EquipmentType.CLIMATIZACION,
    potenciaKva: 50,
    fechaProgramada: '2026-06-30',
    tecnicoTitular: 'Juan Córdova',
    tecnicoTitularId: 'user_5',
    estado: OTStatus.PROGRAMADA
  },
  {
    id: 'OT-251',
    clientId: 'client_1',
    tipoMantenimiento: ServiceType.EMERGENCIA,
    tipoEquipo: EquipmentType.UPS,
    potenciaKva: 30,
    fechaProgramada: '2026-07-05',
    tecnicoTitular: 'Juan Córdova',
    tecnicoTitularId: 'user_5',
    estado: OTStatus.PROGRAMADA
  }
];
